/*global angular:true, is:true, console: true */
App.service('SessionService', ['$http', '$location', 'conf', '$cookies', '$rootScope', function($http, $location, conf, $cookies, $rootScope) {
    'use strict';

    $rootScope.session = {
        state: false,
        timestamp: new Date().getTime() - 300,
        checked: false,
        popupLogin: false
    };

    // var cacheTimeout = 300;
    var host = $location.protocol() + '://' + $location.host();

    // added because on different port it kept hitting the port 80
    if ($location.host() == 'localhost') {
        host = host + ':' + $location.port();
    }

    if (conf.appjs) {
        host = '';
    }

    var origin = window.location.origin || window.location.protocol + "//" + window.location.host;
    //TODO: Move allowed apps on expire to config & build;

    var session_path = [conf.api.root, conf.api.routes.session].join('');
    var token = '';

    var allowedAppsOnExpire = [origin + '/apps/sample'];
    var trackLoginRequests = 0;

    var messages = {
        invalidLogin: "Please try logging in again. Your email address/password did not match our records.",
        expired: "This account has expired. Please go to {{account_settings_link}} and renew subscription.",
        blocked: "This account has been blocked.",
        error: "An Error occurred."
    };

    var session = {};

    function is(thing) {
        return thing !== null && thing !== undefined && thing.toString() == "true";
    }

    session.login = function(loginData, cb) {
        $('.loading-icon').show();
        $http({
                url: host + session_path,
                data: loginData,
                method: 'POST',
                headers: {
                    'X-CSRF-Token': $cookies.csrftoken
                }
            })
            .success(function(response, status) {
                if (response.username) {
                    $rootScope.session.error = undefined;
                    $rootScope.session.state = true;
                    trackLoginRequests = 0;
                    if ($rootScope.session.popupLogin) {
                        $rootScope.session.popupLogin.close();
                    }
                }
                $rootScope.session.timestamp = new Date().getTime();
                angular.extend($rootScope.session, response);

                if (status === 201) {
                    if (!is(response.premium.expired) || is(response.premium.grace) || allowedAppsOnExpire.indexOf(window.location.href)) {
                        if (cb !== undefined) cb($rootScope.session);
                    } else {
                        console.log('TODO: add this link somewhare', messages.expired.replace('{{account_settings_link}}', '<a href="/owner/' + response.username + '/account_settings#premium" target="_top">account settings</a>'));
                    }
                }

            })
            .error(function(response, status, headers) {
                if (status === 403 && response.csrf === true) {
                    trackLoginRequests++;
                    if (trackLoginRequests < 5) {
                        session.getSession(function(s) {
                            session.login(loginData, cb);
                        });
                    }
                } else {
                    $rootScope.session.state = false;
                    $rootScope.session.timestamp = new Date().getTime();
                    if (status == 403 && response.blocked) {
                        $rootScope.session.error = messages.blocked;
                    } else if (status === 401) {
                        $rootScope.session.error = messages.invalidLogin;
                    } else if (status === 400) {
                        $rootScope.session.error = messages.error;
                    }
                    angular.extend($rootScope.session, response);
                    if (cb !== undefined) cb($rootScope.session);
                }
            });
    };


    session.isLoggedIn = function() {
        return $rootScope.session.state;
    };

    session.getSession = function(cb) {
        $http.get(host + session_path)
            .success(
                function(response) {
                    angular.extend($rootScope.session, response.data);
                    $cookies.csrftoken = response.csrf_token;
                    $rootScope.session.state = true;
                    $rootScope.session.cheked = true;
                    $rootScope.session.username = response.username;
                    $rootScope.session.user_id = response.user_id;

                    if ($rootScope.session.popupLogin) {
                        $rootScope.session.popupLogin.close();
                    }
                    if (cb !== undefined) cb($rootScope.session);
                }).error(function(data) {
                $cookies.csrftoken = data.csrf_token;
                if (!$rootScope.session) $rootScope.session = {};
                $rootScope.session.state = false;
                $rootScope.session.timestamp = new Date().getTime();
                $rootScope.session.checked = true;
                if (cb !== undefined) cb($rootScope.session);
            });

    };

    session.logout = function(cb) {
        $http.delete(host + session_path)
            .then(function() {
                $rootScope.session = {
                    state: false,
                    timestamp: new Date().getTime(),
                    checked: true,
                    popupLogin: false
                };
                session.getSession();
                if (cb !== undefined) cb($rootScope.session);
            });
    };

    session.refreshCaptcha = function(cb) {
        $http.get(conf.portalPath + conf.resend_captcha).then(function(response) {
            if (cb !== undefined) cb(response.data);
        });
    };

    if (conf.getSessionInterval !== undefined && conf.getSessionInterval > 0) {
        setInterval(function() {
            session.getSession();
        }, CONF.getSessionInterval);
    }

    return session;
}]);