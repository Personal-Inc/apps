App.filter('capitalize', function() {
    return function(input, all) {
        return (!!input) ? input.replace(/([^\W_]+[^\s-]*) */g, function(txt) {
            return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        }) : '';
    };
});

App.filter('toString', function() {
    return function(item) {
        return item.toString();
    };
});

App.filter('reverse', function() {
    return function(items) {
        if (typeof items !== 'undefined') {
            return items.slice().reverse();
        }
    };
});