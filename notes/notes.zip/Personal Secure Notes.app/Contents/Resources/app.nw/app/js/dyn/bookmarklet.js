(function (w, appId, appOrigin, appPath, settings) {
    var d = w.document;
    if (!w.P3Windows) { w.P3Windows = {}; }
    if (w.P3Apps === undefined) { w.P3Apps = {}; }
    if (w.P3Apps[appId] === undefined) { w.P3Apps[appId] = {}; }
    if (w.P3Apps[appId].settings === undefined) { w.P3Apps[appId].settings = settings; }

    var appWindow = w.P3Windows[appId];
    var isWindowApp = (settings.embeddedType === 'window');

    if (isWindowApp && !appWindow || appWindow !== undefined && appWindow.closed) {
        var windowWidth = settings.windowWidth || 400;
        var windowHeight = settings.windowHeight || 700;
        var l = screen.width;
        w.P3Windows[appId] = w.open(appOrigin + appPath, '_blank', 'width='+windowWidth+',height='+windowHeight+',scrollbars=yes,resizable=no,left=' + l + ',top=0');
    }
    if (w.P3Apps[appId].run !== undefined){
        w.P3Apps[appId].run();
    } else {
        var h = d.getElementsByTagName('head')[0];
        var s = d.createElement('script');
        s.src = appOrigin + "/apps/_/engine/" + appId + "/bootstrap.js?" + new Date().getTime();
        s.type = 'text/javascript';
        h.appendChild(s);
    }
})(window, "@@appId", "@@host", "/apps/@@appId", @@settings);