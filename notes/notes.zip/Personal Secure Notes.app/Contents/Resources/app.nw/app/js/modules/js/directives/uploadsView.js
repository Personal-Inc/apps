angular.module('p3.attachments')
.directive('attachmentsView', function($log){
	return {
		restrict: 'A',
		templateUrl: 'js/modules/js/views/view.html',
		controller: 'uploadsViewCtrl',
		scope: {
			item: '=linkedItem',
			fileService: '=fileService'
		}
	};
});