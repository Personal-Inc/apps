/*global App: true, angular:true */
App.controller('TagsController', ['$scope', '$timeout', '$location', '$route', 'conf', '$rootScope', '$routeParams', 'HelpersFunctions', 'SearchService', 'TagService',
    function($scope, $timeout, $location, $route, conf, $rootScope, $routeParams, HelpersFunctions, SearchService, TagService) {
        'use strict';

        $scope.tagOn = false;
        $scope.showLoading = true;
        $scope.currentTag = $routeParams.tag;

        if (typeof $routeParams.tag === 'undefined') {
            $location.path('/tag/notes%20&%20documents');
        }
        // load tags
        SearchService.search(conf.gemName, 0)
            .then(function(filteredResponse) {
                    $scope.tags = Object.keys(filteredResponse.facets.tag);
                    $scope.showLoading = false;
                    var pagesShown = 1;
                    var pageSize = 10;

                    $scope.paginationLimit = function() {
                        return pageSize * pagesShown;
                    };


                    $scope.hasMoreDataToShow = function() {
                        return pagesShown < ($scope.tags.length / pageSize);
                    };

                    $scope.showMoreData = function() {
                        $scope.loadingMore = true;
                        $timeout(function() {
                            pagesShown = pagesShown + 1;
                            $scope.loadingMore = false;
                        }, 2000);
                    };

                    $scope.leftToLoadTags = pageSize;

                    if ($scope.tags.length > $scope.paginationLimit()) {
                        $scope.leftToLoadTags = $scope.tags.length - $scope.paginationLimit();
                    }

                },
                function(error) {
                    $scope.searching = false;
                });

        $scope.isMyGem = function(note) {
            return (note.owner == $rootScope.session.user_id);
        };

        // get specific tag
        $scope.getTag = function(tag) {
            $scope.loadTag = true;
            $scope.currentTag = tag;
            $scope.tagOn = true;
            var metadata_param = {
                'tag': tag,
                'profile_template': conf.profile_template
            };
            if (typeof $routeParams.tag === 'undefined') {
                $location.path("/tag/" + tag, false);
            }
            TagService.browseTags('profile', metadata_param)
                .then(function(getNotes) {
                        $scope.notes = HelpersFunctions.prepareNotes(getNotes.items);
                        $scope.loadTag = false;
                    },
                    function(error) {
                        $scope.searching = false;
                    });

        };

        if (typeof $routeParams.tag !== 'undefined') $scope.getTag($routeParams.tag);

    }
]);