var App = angular.module('app', ["p3.attachments","p3.gems","ngRoute","ngSanitize","ngCookies","ui.bootstrap","textAngular"]);
App.name = "Personal Secure Notes";
App.id = "notes";
App.isNative = true;
App.constant('config', {"getSessionInterval":60000,"useClient":false,"type":"native","embeddedType":"iframe","windowWidth":570,"windowHeight":650,"allowSameOrigin":true,"autoShow":true,"blacklist":[],"whitelist":[],"iframeStyle":{"width":"380px","height":"300px","position":"absolute","top":"","left":"","right":"","bottom":"","border":"solid 1px silver"},"autoShowLogin":false});
App.config(
  [
      '$httpProvider',
      function($httpProvider) {
        var platform = (process.platform == 'darwin') ? 'osx' : 'windows';
        $httpProvider.defaults.headers.common['Authorization'] = 'Cookie';
        $httpProvider.defaults.headers.common['X-P3-Client'] = platform + '-' + App.id;
      }
  ]
);
