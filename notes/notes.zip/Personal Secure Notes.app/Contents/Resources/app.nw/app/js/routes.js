/*global App: true, angular:true */

angular.module('app')
    .config(
        [
            '$routeProvider',
            function($routeProvider) {
                var path = 'js/views/';
                $routeProvider
                    .when('/', {
                        templateUrl: path + 'login.html'
                    })
                    .when('/add-note', {
                        templateUrl: path + 'browse.html'
                    })
                    .when('/offline', {
                        templateUrl: path + 'offline.html'
                    })
                    .when('/browse', {
                        templateUrl: path + 'browse.html'
                    })
                    .when('/note/:id/:timestamp?/:tag?', {
                        templateUrl: path + 'browse.html'
                    })
                    .when('/timeline', {
                        templateUrl: path + 'timeline.html'
                    })
                    .when('/tags', {
                        templateUrl: path + 'tags.html'
                    })
                    .when('/tag/:tag', {
                        templateUrl: path + 'tags.html'
                    })
                    .otherwise({
                        redirectTo: '/browse'
                    });
            }
        ]
    );