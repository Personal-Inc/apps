App.directive('disableDefault', function() {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            $(function() {
                element.click(function(e) {
                    e.preventDefault();
                });
            });
        }
    };
});

App.directive('windowControl', ['SessionService', '$window', function(SessionService, $window) {
    return {
        restrict: 'A',
        scope: false,
        link: function(scope, element, attrs) {
            $(function() {
                var gui;
                if (typeof require !== 'undefined') gui = require('nw.gui');
                if (typeof gui !== 'undefined') {
                    var win = gui.Window.get();
                    scope.showControlButtons = true;

                    element.find('#windowControlMinimize').on('click', function() {
                        win.minimize();
                    });
                    // Close
                    element.find('#windowControlClose').on('click', function() {
                        // destroying session on window close
                        win.close();
                    });
                    // Max
                    element.find('#windowControlMaximize').on('click', function() {
                        if (win.isMaximized)
                            win.unmaximize();
                        else
                            win.maximize();
                    });
                    win.on('maximize', function() {
                        win.isMaximized = true;
                    });
                    win.on('unmaximize', function() {
                        win.isMaximized = false;
                    });
                } else {
                    scope.showControlButtons = false;
                }

                function syncLeftMenuSize() {
                    angular.element('.notes-list-wrap').height(angular.element($window).height() - 240);
                }
                syncLeftMenuSize();

                angular.element($window).on('resize', syncLeftMenuSize);

            });
        }
    };
}]);

App.directive('browse', function() {
    return {
        restrict: 'A',
        scope: false,
        controller: 'BrowseController',
        link: function(scope, element, attrs) {
            var gui;
            if (typeof require !== 'undefined') gui = require('nw.gui');
            if (typeof gui !== 'undefined') {
                var menu = new gui.Menu();
                menu.append(new gui.MenuItem({
                    type: 'normal',
                    label: 'Add new note',
                    click: function() {
                        angular.element('.side-menu-left a')
                            .first()
                            .click();
                        win.focus();
                    },
                    key: "n",
                    modifiers: "cmd-shift",
                }));

                menu.append(new gui.MenuItem({
                    type: 'normal',
                    label: 'New Note from clipboard',
                    click: function() {
                        win.focus();
                        var clipboard = gui.Clipboard.get();
                        var clipboard_text = clipboard.get('text');
                        scope.$apply(function() {
                            scope.addNew(clipboard_text);
                        });
                    },
                    key: "c",
                    modifiers: "cmd-shift",
                }));

                menu.append(new gui.MenuItem({
                    type: 'normal',
                    label: 'Dev Tools',
                    click: function() {
                        openDevTools();
                    },
                    key: "c",
                    modifiers: "cmd-shift",
                }));



                tray.menu = menu;
            }
        }
    };
});

App.directive('noteBox', ['$rootScope', '$timeout', 'conf', 'HelpersFunctions', 'ShareService', 'ItemService', function($rootScope, $timeout, conf, HelpersFunctions, ShareService, ItemService) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            $(function() {

                element.bind('mouseenter', function() {
                    element.find('.delete-note-left-x').show();
                });
                element.bind('mouseleave', function() {
                    element.find('.delete-note-left-x').hide();
                });

                angular.element('body').click(function() {
                    scope.note.deleteConfirmed = false;
                    scope.$apply();
                });

                function afterDelete() {
                    $rootScope.noteDeleted = true;
                    scope.noteContainer = null;
                    scope.loadingNote = false;
                    scope.currentTimestamp = null;
                    scope.currentId = null;
                    scope.notes.total--;
                }

                scope.deleteNote = function(note_obj) {
                    $rootScope.noteDeleted = false;
                    scope.deletingNote = true;

                    $timeout(function() {
                        if (scope.isMyGem(note_obj)) {
                            scope.notes.splice(HelpersFunctions.objIndexOf(scope.notes, note_obj.title), 1);
                            ItemService.deleteItem($rootScope.session.user_id, conf.profile_template, note_obj.id, $rootScope.session.user_id)
                                .success(function() {
                                    afterDelete();
                                })
                                .error(function() {

                                });
                        } else {
                            ShareService.stopShare(note_obj.owner, conf.profile_template, note_obj.id, $rootScope.session.user_id).success(function() {
                                afterDelete();
                            });
                        }
                    }, 2000);

                };

            });
        }
    };
}]);

App.directive('addTag', ['TagService', '$timeout', function(TagService, $timeout) {
    return function(scope, element, attrs) {
        angular.element('.input-short').focus();
        element.find('.add-tag').bind("keydown keypress", function(event) {
            scope.note.addTagError = false;
            if (typeof scope.note.tag === 'undefined') scope.note.tag = [];
            if (event.which === 13) {
                scope.note.savingTag = true;

                scope.$apply(function() {
                    scope.$eval(attrs.ngEnter, {
                        'event': event
                    });
                    if (scope.note.new_tag && scope.note.tag.indexOf(scope.note.new_tag) === -1) {

                        $timeout(function() {
                            var metadata_param = {
                                'tag': scope.note.new_tag
                            };

                            TagService.addTag('profile', metadata_param, scope.currentId)
                                .then(function(response) {
                                    scope.note.addTagOn = false;
                                    scope.note.savingTag = false;
                                    scope.note.tag.push(scope.note.new_tag);
                                    scope.note.new_tag = null;
                                });

                        }, 1000);
                    } else {
                        scope.note.savingTag = false;
                        scope.note.addTagError = true;
                    }
                });
                event.preventDefault();
            } else if (event.which === 27) {
                scope.note.addTagOn = false;
                scope.$apply();
            }


        });
        element.on('click', '.fa-trash-o', function() {
            angular.element(this).parent().addClass('deleting');
        });
    };
}]);

App.directive('showFocus', function($timeout) {
    return function(scope, element, attrs) {
        scope.$watch(attrs.showFocus,
            function(newValue) {
                $timeout(function() {
                    if (newValue) element.focus();
                });
            }, true);
    };
});

App.directive('shareNote', ['ShareService', '$timeout', function(ShareService, $timeout) {
    return function(scope, element, attrs) {
        scope.loadShareData();
        element.find('.share-input').bind("keydown keypress", function(event) {
            scope.shareNote.error = null;
            if (typeof scope.shareNote.emailAddress !== 'undefined' && (event.which === 13 || event.which === 188 || event.which === 0 || event.which === 32 || event.which === 9)) {
                scope.goShareNote();
                event.preventDefault();
            } else if (event.which === 27) {
                scope.shareNote.error = null;
                scope.shareNote.emailAddress = null;
                scope.note.shareContainerLoaded = false;
                scope.$apply();
            }
        });
    };
}]);