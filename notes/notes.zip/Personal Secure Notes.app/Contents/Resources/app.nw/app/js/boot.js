/* global angular:false, App: false*/
(function(){
  'use strict';
  var context;

  function init(ctx){
    context = ctx;
  }

  function run(){
    angular.element(document).ready(function () {
      App.constant('Context', context);
      angular.bootstrap(document, ['app']);
    });
  }

  if (window.P3Apps === undefined){
    window.P3Apps = {};
  }
  
  window.P3Apps[App.id] = {
    init: init,
    run: run
  };
})();