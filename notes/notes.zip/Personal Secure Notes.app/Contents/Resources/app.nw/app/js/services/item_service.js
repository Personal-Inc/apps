/*global _: true, angular: true */
angular.module('p3.gems')
.service('ItemService',
  [
    '$http',
    '$q',
    'conf',
    '$log',
    function($http, $q, conf, $log) {
      'use strict';
      var path = [conf.api.root, conf.api.routes.profiles].join('');
      var item = {};
      var loadedItems = {};
      var itemsFetching = [];

      function cacheLoadedItem(id, item){
        loadedItems[id] = item;
      }

      // cache invalidation
      item.invalidateCachedItem = function(id){
        delete loadedItems[id];
      };

      // fetch info on gem
      item.preloadItem = function(profileId){
        var canceller = $q.defer();

        var cancel = function(){
          canceller.resolve('Cancelled');
        };

        itemsFetching.push(profileId);

        var load = $http({
          url: path,
          method: "POST",
          timeout: canceller.promise,
          cache: true,
          data: {
            "profile_instance" : [profileId],
            "include" : ["field_template", "value"]
          }
        }).then(function(response){
          itemsFetching.splice(itemsFetching.indexOf(profileId), 1);
          var returnableItem = modelInstanceData(response.data);
          cacheLoadedItem(profileId, returnableItem);
          return returnableItem;
        });

        return {
          load: load,
          cancel: cancel
        };
      };

      item.getItem = function(profileId, fetchByTemplate){
        if(typeof fetchByTemplate === 'undefined') fetchByTemplate = false;
        var def = $q.defer();
        if(loadedItems[profileId]){
          def.resolve(loadedItems[profileId]);
        }
        else {
          if(!fetchByTemplate){
            if(!~itemsFetching.indexOf(profileId)){
              itemsFetching.push(profileId);
              item.preloadItem(profileId).load.then(
                function(instanceData){
                  itemsFetching.splice(itemsFetching.indexOf(profileId), 1);
                  def.resolve(instanceData);
                },
                function(){
                  def.reject('Internal error while fetching Gem');
                });
            }
            else {
              var tried = 0;
              var waitForResolutionInProgress = setInterval(function(){
                if(loadedItems[profileId]){
                  clearInterval(waitForResolutionInProgress);
                  itemsFetching.splice(itemsFetching.indexOf(profileId), 1);
                  def.resolve(loadedItems[profileId]);
                }
                // did not succeed after 10 seconds
                if(tried === 100){
                  clearInterval(waitForResolutionInProgress);
                  itemsFetching.splice(itemsFetching.indexOf(profileId), 1);
                  def.reject('Failed to load gem that was supposed to preload, after 10 seconds of waiting');
                }
                tried++;
              }, 100);
            }
          }
          else def.reject('Tried loading non-cached Gem via template Id fetch');
        }
        return def.promise;
      };

      // delete gem (also serves as stop share from self)
      item.deleteItem = function(userId, templateId, profileId, ownerId){
        var hitUserId = userId;
        if(userId !== ownerId) hitUserId = ownerId;
        var path = [conf.api.root, conf.api.routes.gems, encodeURIComponent([hitUserId, templateId, profileId].join('#'))].join('');
        if(userId !== ownerId) path += '/access/';

        return $http({
          url: path,
          method: "DELETE"
        });
      };

      // creates a new item
      item.createItem = function(templateId){
        var def = $q.defer();
        var body = {
          profile_template: templateId,
          only_new: true,
          include: ['field_template']
        };

        $http.post(path, body).success(function(data){
          var instanceData = prepareInstanceDataForAdd(modelInstanceData(data));
          cacheLoadedItem(templateId, instanceData);
          def.resolve(instanceData);
        });

        return def.promise;
      };


      item.fetchFiletypesSchema = function(){
      var path = [conf.static.root, conf.static.routes.filetypes].join('');
      return $http({
          url: path,
          method: 'GET',
          cache: true
        });
      };

      // change all ids in instances to have instance ID prepended
      item.convertInstancesForEdit = function(newInstances, instanceId){
        return changePrefixes(newInstances, instanceId);
      };

      /////////////

      function modelInstanceData(inputData){
        var outputData = [];

        // iterate through each instance of gem data
        angular.forEach(inputData, function(v){
          if(v.value === null){ v.value = ''; }
          v.show = (v.field_template.name !== 'Gem Name') ? true : false;

          outputData.push({
            id: v.id,
            label: v.field_template.name,
            value: v.value,
            semantic: v.field_template.semantic,
            sensitive: v.field_template.sensitive,
            multi: v.field_template.multi,
            description: v.field_template.description,
            show: v.show,
            order: v.field_template.order
          });

        });

        return outputData;
      }

      // prepend new0 keyword to all instance ids so they create new gems
      function prepareInstanceDataForAdd(inputData){
        return changePrefixes(inputData, 'new0');
      }

      function changePrefixes(instances, newPrefix){
        return angular.forEach(instances, function(v){
          var splitId = v.id.split('.');
          splitId.shift();
          v.id = [newPrefix, splitId.join('.')].join('.');
        });
      }

      return item;
    }
  ]
);