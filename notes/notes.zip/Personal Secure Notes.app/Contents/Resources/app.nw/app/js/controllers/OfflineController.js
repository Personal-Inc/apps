/*global App: true, angular:true */
App.controller('OfflineController', ['$scope', '$rootScope', 'HelpersFunctions',
    function($scope, $rootScope, HelpersFunctions) {
        'use strict';

        $rootScope.fromOffline = true;
        $scope.currentId = false;

        $scope.saveOfflineNote = function(param) {
            if (typeof $scope.note.id !== 'undefined') {
                storedb('notes').remove({ "_id": $scope.note.id });
            }
                if ($scope.note)
                    storedb('notes').insert({
                        "title": $scope.note.title,
                        "body": $scope.note.body,
                        "timestamp": event.timeStamp
                    }, function(err, result) {
                        if (err) {
                            // do some error handling
                        } else {
                            $('#note-info').html('Note saved: ' + $scope.note.title).removeClass('hide');
                            $scope.note = null;
                        }
                    });
            $scope.offlineNotes = storedb('notes').find();
        };

        $scope.showOfflineNote = function(param) {
            var offlineNote = storedb('notes').find({
                "_id": param
            });
            $scope.note = {
                id: param,
                title: offlineNote[0].title,
                body: offlineNote[0].body
            };
            $scope.currentId = $scope.note.id;
            $scope.note.editing = true;
            $scope.note.showAddContainer = true;
        };


        $scope.deleteOfflineNote = function(note) {
            storedb('notes').remove({
                "_id": note._id
            }, function(err) {
                if (!err) {
                    $('#note-info').html('note removed: ' + note.title).removeClass('hide');
                    $('#note_' + note._id).css('visibility','hidden');
                    $scope.offlineNotes.splice(HelpersFunctions.objIndexOf($scope.offlineNotes, note._id), 1);
                    $scope.note = null;
                    $scope.currentId = null;
                }
            });
        };

    }
]);