/*global angular: true */
angular.module('p3.gems')
.service('SearchService',
	[
		'conf',
		'$log',
		'$http',
		'$q',
		function(conf, $log, $http, $q){

			/*
				Index of all available service methods
				- search ( term, offset, sortBy, filters ) 		[ returns promise with actual gems/profiles from metadata browse ]
				- searchProfiles ( term, limit ) 				[ returns promise with templates for gems ]
				- getProfileTemplateCategories ( nil ) 			[ returns all categories possible for profile-templates ]
				- getFacets ( forceRefresh ) 					[ returns subset of all profile templates that user owns + caches them in the service ]
				- indexProfileTemplates ( subset(optional) ) 	[ returns all profile templates available + caches them in the service ]
				- getProfileTemplateById ( templateId )			[ returns name (possibly more metadata) of the provided template ID ]
				- getProfilesByTemplateId (templateId)			[ returns all profiles filtered via template id ]
				- getDefaultFacets								[ returns default array of product defined facets ]
			*/

			'use strict';
			var opts = { withCredentials: conf.withCredentials, cache: true };
			var search = {
				perPage: 10,
				activeSearch: {},
				currentUser: {}
			};

			var path = [conf.api.root, conf.api.routes.search].join('');

			var bodyBase = {
				object_type: 'profile',
				facets: ['category', 'tag', 'profile_template'],
				limit: search.perPage,
				offset: 0,
				include: ['metadata.name', 'metadata.owner', 'metadata.owner_username', 'metadata.owner_email', 'metadata.profile_template', 'metadata.template_name', 'shares', 'metadata.updated_timestamp', 'metadata.tag', 'attachments'],
				sort: [{name: 'asc'}]
			};

			var profileTemplates = { notLoaded: true };

			function prepareItems(items){
				// item preparation
				if(items.items){
					angular.forEach(items.items, function(item){
						// Convert attachments object ( !? ) to array ( :) )
						if(_.isEmpty(item.attachments)){
							delete item.attachments;
							item.attachments = [];
						}
						else {
							var attachs = angular.copy(item.attachments);
							delete item.attachments;
							item.attachments = [];
							angular.forEach(attachs, function(attach){
								item.attachments.push(attach);
							});
						}
					});
				}
				return items;
			}

			// routing function for search, determining which method to use
			search.search = function(term, offset, sortBy, filters){
				// Offset setup
				if(typeof offset === 'undefined') offset = 0;
				else bodyBase.offset = offset;

				// Sort by parameter
				if(typeof sortBy !== 'undefined') bodyBase.sort = sortBy;

				// Additional metadata filtering
				if(typeof filters !== 'undefined'){
					angular.forEach(filters, function(filter, filterParentKey){
						if(typeof bodyBase[filterParentKey] === 'undefined'){
							bodyBase[filterParentKey] = filter;
						}
						else {
							angular.forEach(filter, function(filterValue, filterKey){
								bodyBase[filterParentKey][filterKey] = filterValue;
							});
						}
					});
				}

				var def = $q.defer();
				var splitTerm = term.split(':');

				if(splitTerm.length > 1){
					var searchByTerm = splitTerm[1];
					switch(splitTerm[0]){
						case 'gems':
							search.getFacets().then(function(){
								var templateId = getTemplateIdByName(searchByTerm);
								if(templateId){
									searchByProfileTemplate(templateId)
										.success(function(data){ def.resolve(prepareItems(data)); })
										.error(function(error){ def.reject(error); });
								}
								else {
									def.reject();
								}
							});
							break;
						case 'gem':
							searchByIds([searchByTerm])
								.success(function(data){ def.resolve(prepareItems(data)); })
								.error(function(error){ def.reject(error); });
							break;
						case 'tag':
							searchByTag(searchByTerm)
								.success(function(data){ def.resolve(prepareItems(data)); })
								.error(function(error){ def.reject(error); });
							break;
						case 'from':
							searchByOwner(searchByTerm)
								.success(function(data){ def.resolve(prepareItems(data)); })
								.error(function(error){ def.reject(error); });
							break;
						case 'to':
							searchByFollower(searchByTerm)
								.success(function(data){ def.resolve(prepareItems(data)); })
								.error(function(error){ def.reject(error); });
							break;
						case 'connection':
							searchByConnection(searchByTerm)
								.success(function(data){ def.resolve(prepareItems(data)); })
								.error(function(error){ def.reject(error); });
							break;
						case 'name':
							searchByName(searchByTerm)
								.success(function(data){ def.resolve(prepareItems(data)); })
								.error(function(error){ def.reject(error); });
							break;
						default:
							searchByAll(term)
								.success(function(data){ def.resolve(prepareItems(data)); })
								.error(function(error){ def.reject(error); });
							break;
					}
				}
				else {
					searchByAll(term)
						.success(function(data){ def.resolve(prepareItems(data)); })
						.error(function(error){ def.reject(error); });
				}

				return def.promise;
			};

			search.searchProfiles = function(term, limit){
				var def = $q.defer();

				if(typeof limit === 'undefined') limit = 5;

				var body = {
					include: ['metadata.name', 'metadata.category', 'metadata.tag'],
					limit: limit,
					object_type: 'profile_template',
					mode: 'query'
				};

				var searchIt = true;

				var splitTerm = term.split(':');
				// If search term has : prefix
				if(splitTerm.length > 1){
					if(splitTerm[0] === 'gems'){
						search.getFacets().then(function(){
							var templateId = getTemplateIdByName(splitTerm[1]);
							if(templateId){
								body.id = templateId;
							}
						});
					}
					else if(splitTerm[0] === 'category'){
						body.metadata = {
							category: splitTerm[1]
						}
					}
					// DO NOT SEARCH for these prefixes
					else if(~['from', 'to', 'connection', 'gem'].indexOf(splitTerm[0])){
						searchIt = false;
					}
				}
				else {
					// this searches for templates by 1) name (partial match) and 2) tag (exact match)
					body.criteria = [
						{
							object_type: 'profile_template',
							metadata: {
								tag: term
							}
						},
						{
							object_type: 'profile_template',
							search_metadata: {
								name: {
									and: term.split(' ')
								}
							}
						}
					];
				}

				if(searchIt){
					$http.post(path, body)
						.success(function(response){ def.resolve(response); })
						.error(function(error){ def.reject(error); });
				}
				else {
					def.reject('No search');
				}

				return def.promise;
			};

			search.getProfileTemplateCategories = function(){
				var body = {
					limit: 100,
					offset: 0,
					object_type: 'profile_template',
					facets: ['category'],
					facets_only: true
				};

				return $http.post(path, body, opts);
			};

			search.getFacets = function(forceRefresh){
				var def = $q.defer();

				if(typeof forceRefresh === 'undefined') forceRefresh = false;

				if(typeof search.facets === 'undefined' || forceRefresh){
					var returningFacets = [];
					var returningTagFacets = [];

					var body = {
						limit: 30,
						offset: 0,
						object_type: 'profile',
						facets: ['profile_template', 'tag'],
						facets_only: true
					};

					$http.post(path, body, opts)
					.success(function(response){
						prepareFacetedData(response.facets.profile_template).success(function(returned){

							angular.forEach(returned.items, function(value) {
								if(typeof response.facets.profile_template[value.id] !== 'undefined'){
									returningFacets.push({
										'id': value.id,
										'name': value.metadata.name[0],
										'count': response.facets.profile_template[value.id],
										'category': value.metadata.category[0]
									});
								}
							});

							if(returningFacets.length){
								search.facets = {categories: null, tags: null};
								// do the categories
								search.facets.categories = sortFacetsByPopularity(returningFacets); // save to service for future use
								// do the tags
								search.facets.tags = [];
								angular.forEach(response.facets.tag, function(tagCount, tag){
									search.facets.tags.push({name: tag, count: tagCount});
								});
								// return all
								def.resolve(search.facets);
							}
							else {
								search.ftux = { addedGems: 0 };
								def.reject();
								// search.facets = search.getDefaultFacets();
							}
						});
					});
				}
				else {
					def.resolve(search.facets);
				}

				return def.promise;
			};

			search.indexProfileTemplates = function(subset){
				var def = $q.defer();
				var body = {
					object_type: 'profile_template',
					include: ['metadata.name'],
					limit: 100
				};

				if(typeof subset !== 'undefined') body.ids = subset;

				if(profileTemplates.notLoaded){
					profileTemplates = {};
					$http.post(path, body, opts).success(function(data){
						angular.forEach(data.items, function(template){
							profileTemplates[template['id']] = template.metadata.name[0];
						});
						def.resolve(profileTemplates);
					});
				}
				else {
					def.resolve(profileTemplates);
				}
				return def.promise;
			};

			search.getProfileTemplateById = function(profileTemplateId){
				var def = $q.defer();

				if(profileTemplates){
					def.resolve(profileTemplates[profileTemplateId]);
				}
				else {
					search.indexProfileTemplates().then(function(templates){
						def.resolve(templates[profileTemplateId]);
					}, function(){
						def.reject();
					});
				}

				return def.promise;
			};

			search.getProfilesByTemplateId = function(templateId){
				var def = $q.defer();

				searchByProfileTemplate(templateId)
					.success(function(data){ def.resolve(prepareItems(data)); })
					.error(function(error){ def.reject(error); });

				return def.promise;
			};

			search.getDefaultFacets = function(){
				return [
					{
						'id': "0040",
						'name': "Credit & Debit Card",
						'category': "Finance"
					},
					{
						'id': "0058",
						'name': "Membership & Rewards Program",
						'category': "IDs"
					},
					{
						'id': "0036",
						'name': "Password",
						'category': "Passwords & Wi-Fi"
					}
				];
			}

			//////////////////

			// search data by all criteria
			function searchByAll(term){
				var body = angular.copy(bodyBase);

				if(term !== '*'){
					body.search_metadata = {
						name: term,
						template_name: term,
						category: term,
						tag: term,
						owner_username: term,
						owner_email: term
					};
				}

				return $http.post(path, body, opts);
			}

			// search data by profile template id
			function searchByProfileTemplate(templateId){
				var body = angular.copy(bodyBase);
				body.metadata = {
					profile_template: templateId
				};

				return $http.post(path, body, opts);
			}

			// search gems by some tag
			function searchByTag(tag){
				var body = angular.copy(bodyBase);
				body.metadata = {
					tag: tag
				};

				return $http.post(path, body, opts);
			}

			// search by follower, returns all gems shared to some contact
			function searchByFollower(user){
				var body = angular.copy(bodyBase);
				body.metadata = {
					follower: user,
					owner: search.currentUser.id
				};

				return $http.post(path, body, opts);
			}

			// search data by it's owner
			function searchByOwner(owner){
				var body = angular.copy(bodyBase);

				var axis = (~owner.indexOf('@')) ? 'owner_email' : 'owner_username';
				body.metadata = {follower: search.currentUser.id};
				body.metadata[axis] = owner;

				return $http.post(path, body, opts);
			}

			function searchByConnection(connection){
				var body = angular.copy(bodyBase);
				body.criteria = [
					{
						object_type: 'profile',
						metadata: {
							owner: search.currentUser.id,
							follower: connection
						}
					},
					{
						object_type: 'profile',
						metadata: {
							follower: search.currentUser.id,
							owner: connection
						}
					}
				];
				return $http.post(path, body, opts);
			}

			// search gems directly by id's
			function searchByIds(ids){
				var body = angular.copy(bodyBase);
				body.metadata = {};
				body.id = ids;

				return $http.post(path, body, opts);
			}

			// search data by name
			function searchByName(name){
				var body = angular.copy(bodyBase);
				body.metadata = {
					name: name
				};

				return $http.post(path, body, opts);
			}

			// fetches actual data about facets
			function prepareFacetedData(inputData){
				var body = {
					limit: 100,
					offset: 0,
					object_type: 'profile_template',
					ids: Object.keys(inputData)
				};

				return $http.post(path, body, opts);
			}

			function sortFacetsByPopularity(facets){
				return facets
				.sort(function(a, b){
					var difcount = b.count - a.count;
					if(difcount === 0){
						if (a.name < b.name) return -1;
						else if (a.name > b.name) return 1;
						else return 0;
					}
					else {
						return difcount;
					}
				});
			}

			// get id of template by providing exact name
			function getTemplateIdByName(name){
				var returningId;
				if(name.toLowerCase() == 'files photos & top secret notes'){
					returningId = '0175';
				}
				else {
					search.facets.categories.map(function(value){
						if(value.name.toLowerCase() == name.toLowerCase()) returningId = value.id;
					});
				}
				return returningId;
			}

			return search;
		}
	]
);
