(function(w, $) {
    "use strict";
    if (w.P3Env === undefined) {
        // needed for apps that are using login component only
        w.P3Env = {};
    }
    var loginPath = "/apps/login/v1?app=" + w.P3Env.contextAppName;
    var sessionPath = "/api/v1/session";
    var customOptions = {};
    var callback;
    var options;

    // var allowedAppsOnExpire = ['sample'];

    w.P3Env.withSession = function(cb, options){
        callback = cb;
        customOptions = options || {async : true};
        if (options !== undefined && options.skip === true){
            //run after everything else
            setTimeout( function (){
                openLogin({ context : "init" });
                sessionChange(false);
            }, 1);
            return;
        }
        $.ajax( {
            url : sessionPath,
            async : customOptions.async,
            success : function(session){
                if (session.expires !== undefined && session.expires !== -1) {
                    sessionChange(session);
                    callback(session);
                } else {
                    openLogin({ context : "init" });
                    sessionChange(false);
                }
            },
            error : function(r){
                if (r.status == 404){
                    openLogin({ context : "init" });
                    sessionChange(false);
                } else {
                    //console.log(r);// TODO report error
                }
            }
        });
    };

    // session monitoring
    function sessionCheck(){
        if (sessionChangeHandler === undefined) return;
        $.ajax({
            url : sessionPath,
            success : function(session){
                return sessionChange(session);
            },
            error : function(){
                return sessionChange(false);
            }
        });
    }
    
    var sessionState;
    function sessionChange(state){
        if (sessionChangeHandler === undefined) return;
        var oldState = sessionState;
        if (oldState === undefined || oldState.user_id != state.user_id || state.pipeEmail) {
            var settings = w.P3Env.config();
            sessionState = state;
            if (dontSupportBucket(settings, state)){
                window.location.href = '/login/signin';
            }
            if (state === false && oldState !== state && settings.loginOnLostSession !== false){
                openLogin({ context : "change" });
            }
            if (state && login.opened) {
                closeLogin();
            } 
            sessionChangeHandler(state);
        }
    }

    function dontSupportBucket(settings, state) {
        return (state && state.bucket_mode === true && settings.supportBucketSession !== true);
    }

    var sessionCheckInterval = 60000;
    var sessionChangeHandler;
    w.P3Env.registerEventProvider("sessionChange", function(handler) {
        sessionChangeHandler = handler;
        sessionCheck();
        setInterval(sessionCheck, sessionCheckInterval);
    });

    w.P3Env.endSession = function() {
        $.ajax({ 
            url : sessionPath, 
            type : "DELETE",
            success : function(){
                sessionChange(false);
            }
        });
    };

    // context page is either app page for standalone, or parent page in iframed apps
    var contextPageWidth = w.P3Env.isIframeContext ? 1440 : w.document.documentElement.offsetWidth;
    var topOffset = w.P3Env.isIframeContext ? 140 : 0;
    var height = w.P3Env.isIframeContext ? 395 : 250;
    var loginSize = { w : 340, h : height };
    var loginPlacing = (w.P3Env.contextAppName === 'login' && contextPageWidth <= (loginSize.w+100)) ? {top: 0, left: 0} : { top : 60 + topOffset, left : contextPageWidth / 2 - loginSize.w / 2 };
    var popupSpecs = [
        'width=' + loginSize.w,
        'height=' + loginSize.h,
        'left=' + loginPlacing.left,
        'top=' + loginPlacing.top,
        'scrollbars=yes',
        'resizable=no'
    ].join(",");
    var iframeSpecs = {
        width :  loginSize.w,
        height : loginSize.h,
        border : "1px solid silver",
        background : "#FFF",
        position : "fixed",
        top : loginPlacing.top,
        left : loginPlacing.left
    };
    // var pingInterval;
    var popup;
    var iframe;
    var loginButton;
    $(function() {
        loginButton = $("#app-login");
        loginButton.on("click", function(){
            var loginAttrs = loginButton.attr('data-login-params');
            if (loginAttrs){
                loginPath += "&" + loginAttrs;
            }
            popup = w.open(loginPath, '_blank', popupSpecs);
            return false;
        });
    });
    
    var login = { opened : false };
    function openLogin(options) {
        login.context = options.context;
        login.opened = true;
        login.options = options;
        if (w.P3Env.isIframeContext) {
            loginButton.addClass("activated");
        } else {
            options = $.extend({}, iframeSpecs, {
                border : customOptions.border,
                container : customOptions.container,
                background : customOptions.background,
                top : customOptions.top
            });
            if (options.container === undefined) {
                options.position = "fixed";
                options.container = "body";
            } else {
                options.position = "";
            }
            iframe = $('<iframe />', {
                id :   'loginFrame',
                name : 'loginFrame',
                src : loginPath,
                seamless : "seamless"
            }).css(options);
            if (options.container && $(options.container).find("#loginFrame").length === 0) {
                iframe.appendTo(options.container);
            }
        }
    }
    
    function closeLogin() {
        if (popup) popup.close();
        if (iframe) {
            iframe.remove();
            if (login.options && login.options.container) {
                $(options.container).remove();
            }
        }
        
        loginButton.removeClass("activated");
        login.opened = false;
    }

    w.P3Env.provideSession = function(session) {
        var ssn = JSON.parse(session);
        closeLogin();
        if (login.context == "init"){
            callback(ssn);
        }
        sessionChange(ssn);
    };

    w.P3Env.resizeLoginFrame = function(width, height) {
        iframe.height(height);
    };

})(window, window.jQuery);
// temporary implies jquery availability, should be expressed as a dependency explicitlly
