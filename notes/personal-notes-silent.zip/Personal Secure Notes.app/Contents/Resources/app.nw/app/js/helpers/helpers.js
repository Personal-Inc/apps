/*global angular:true, is:true, console: true */
App.service('HelpersFunctions', ['$filter', function($filter) {

    var helpers = {};

    helpers.groupNotes = function(data, attribute) {

        var timeline = [];
        var dateValue = "";
        var group;
        this.sortMe(data, attribute);

        for (var i = 0; i < data.length; ++i) {
            var single_note = data[i];
            if (single_note[attribute] !== dateValue) {
                group = {
                    note_date: single_note[attribute],
                    notes: []
                };
                dateValue = group.note_date;
                timeline.push(group);
            }
            group.notes.push(single_note);
        }
        return timeline;
    };

    helpers.sortMe = function(collection, name) {
        collection.sort(
            function(a, b) {
                if (a[name] <= b[name]) {
                    return (-1);
                }
                return (1);
            }
        );
    };

    helpers.objIndexOf = function(data, val) {
        var cnt = -1;
        for (var i = 0, n = data.length; i < n; ++i) {
            cnt++;
            for (var o in data[i]) {
                if (data[i].hasOwnProperty(o) && data[i][o] == val) return cnt;
            }
        }
        return -1;
    };

    helpers.prepareNotes = function(filteredData) {

        var notes = [];
        angular.forEach(filteredData, function(data) {

            var filter_date = data.metadata.updated_timestamp.toString().slice(0, -3) * 1000;

            var myDate = $filter('date')(filter_date, "dd-MM-yyyy");
            myDate = myDate.split("-");
            var newDate = myDate[1] + "/" + myDate[0] + "/" + myDate[2];
            var date_final = new Date(newDate).getTime();

            notes.push({
                'id': data.id,
                'title': data.metadata.name.toString(),
                'timestamp': filter_date,
                'date_final': date_final,
                'tag': data.metadata.tag,
                'follower': data.metadata.follower,
                'owner': data.metadata.owner[0].id,
                'owner_username': data.metadata.owner_username[0],
                'metadata': {
                    'profile_template': data.metadata.profile_template
                },
                'attachments': data.attachments,
                'loaded': false
            });

        });

        return notes;
    };

    return helpers;

}]);