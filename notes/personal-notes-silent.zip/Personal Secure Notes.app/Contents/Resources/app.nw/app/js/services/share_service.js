/*global App: true */

angular.module('p3.gems')
.service('ShareService',
  [
    '$log',
    '$http',
    '$q',
    'conf',
    function($log, $http, $q, conf){
      'use strict';
      var opts = {withCredentials: conf.withCredentials, cache: true};
      var share = { followersToLoad: [], followersPerPage: 3 };

      // share gem(s)
      share.startShare = function(profileIds, grantedPermission, grantedFollowers){
        var path = [conf.api.root, conf.api.routes.share].join('');

        var body = {
          objects: [],
          permission: {
            rights: grantedPermission
          },
          targets: []
        };

        // push all profiles to the request
        angular.forEach(profileIds, function(profileId){
          body.objects.push({type: 'profile', id: profileId});
        });

        angular.forEach(grantedFollowers, function(followerId){
          body.targets.push({type: 'owner', id: followerId});
        });

        return $http({
          url: path,
          method: 'POST',
          data: body
        });
      };

      // stop sharing one gem
      share.stopShare = function(ownerId, templateId, profileId, followerId){
        var path = [conf.api.root, conf.api.routes.gems, [encodeURIComponent([ownerId, templateId, profileId].join('#')), 'access', followerId].join('/')].join('');
        return $http({
          url: path,
          method: 'DELETE'
        });
      };

      // internal function for splitting the id and taking what matters
      function parseConnectionData(inputData, real){

        if(typeof real === 'undefined') real = false;
        var followersDataFresh = [];
        angular.forEach(inputData.items, function(follower){
          if((real && follower.metadata.username.length) || !real){
            follower.returnedId = follower.id;
            follower.id = follower.id.split('#')[1];
            followersDataFresh.push(follower);
          }
        });
        return followersDataFresh;
      }

      share.setFollowersToBeLoaded = function(userId, followersFromMetadata){
        share.followersToLoad = followersFromMetadata.map(function(follower){
          return [userId, follower].join('#');
        });
      };

      // get all users to whom this item(gem) was shared
      share.getFollowersData = function(offset){
        if(typeof offset === 'undefined') offset = 0;

        var path = [conf.api.root, conf.api.routes.search].join('');
        var nowLoadTheseFollowers = share.followersToLoad.slice(offset, share.followersPerPage+offset);

        var body = {
          object_type: 'contact',
          id: nowLoadTheseFollowers,
          limit: share.followersPerPage
        };

        var defer = $q.defer();

        $http.post(path, body).success(function(followersDataRaw){
          defer.resolve(parseConnectionData(followersDataRaw));
        })
        .error(function(){
          defer.reject();
        });

        return defer.promise;
      };

      share.searchConnections = function(term, real){

        var axis = (~term.indexOf('@')) ? 'email' : 'username';

        if(typeof real === 'undefined') real = false;

        var body = {
          object_type: 'contact',
          search_metadata: {
            name: term
          }
        };

        body.search_metadata[axis] = term;

        var defer = $q.defer();

        $http.post([conf.api.root, conf.api.routes.search].join(''), body).success(function(followersDataRaw){
          defer.resolve(parseConnectionData(followersDataRaw, real));
        })
        .error(function(){
          defer.reject();
        });

        return defer.promise;
      };

      share.getAllConnections = function(){
        var defer = $q.defer();

        $http.post([conf.api.root, conf.api.routes.search].join(''), {object_type: 'contact'}).success(function(followersDataRaw){
          defer.resolve(parseConnectionData(followersDataRaw));
        })
        .error(function(){
          defer.reject();
        });

        return defer.promise;
      };

      return share;
    }
  ]
);
