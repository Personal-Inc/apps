/*global App: true */

angular.module('p3.gems')
.service('ShareService',
  [
    '$log',
    '$http',
    '$q',
    'conf',
    function($log, $http, $q, conf){
      'use strict';
      var opts = {withCredentials: conf.withCredentials, cache: true};
      var share = { followersToLoad: [], followersPerPage: 3 };

      // share gem(s)
      share.startShare = function(profileIds, grantedPermission, grantedFollowers){
        var path = [conf.api.root, conf.api.routes.share].join('');

        var body = {
          objects: [],
          permission: {
            rights: grantedPermission
          },
          targets: []
        };

        // push all profiles to the request
        angular.forEach(profileIds, function(profileId){
          body.objects.push({type: 'profile', id: profileId});
        });

        angular.forEach(grantedFollowers, function(followerId){
          body.targets.push({type: 'owner', id: followerId});
        });

        return $http({
          url: path,
          method: 'POST',
          data: body
        });
      };

      // stop sharing one gem
      share.stopShare = function(ownerId, templateId, profileId, followerId){
        var path = [conf.api.root, conf.api.routes.gems, [encodeURIComponent([ownerId, templateId, profileId].join('#')), 'access', followerId].join('/')].join('');
        return $http({
          url: path,
          method: 'DELETE'
        });
      };

      // get feeds
      share.getFeeds = function(count, unread, from){
        if(typeof unread === 'undefined') var unread = true;
        if(typeof count === 'undefined') var count = 5;

        var buildingPath = [conf.api.root, conf.api.routes.messages, "/?count=", count, "&unread=", unread];

        if(typeof from !== 'undefined') buildingPath.push('&from='+encodeURIComponent(from));

        var path = buildingPath.join('');
        var defer = $q.defer();

        $http({
          url: path,
          method: 'GET'
        })
        .success(function(activityList){
          defer.resolve(parseActivityData(activityList));
        })
        .error(function(){
          defer.reject();
        });

        return defer.promise;
      };

      // get activity count
      share.getActivityCount = function(){
        var path = [conf.portalPath, conf.api.routes.activityCount].join('');
        return $http({
          url: path,
          method: 'GET'
        });
      };

      //internal function for making activities json
      function parseActivityData(activityList){
        var message_text;
        return angular.forEach(activityList.messages, function(activity){
          activity.message_timestamp *= 1000;
          if(activity.message_type === 'osm'){
            activityList.messages.splice(activityList.messages.indexOf(activity), 0, {"message_id":activity.message_id,"message_type":"osm","message_contact_email":"admin@personal.com","message_contact_id":activity.message_contact_id,"message_timestamp":activity.message_timestamp,"message_read":activity.message_read,"message":"Add most popular data for forms in Fill It.", "message_link": "https://www.fillit.com/", "message_contact_avatar":activity.message_contact_avatar});
            activityList.messages.splice(activityList.messages.indexOf(activity), 0, {"message_id":activity.message_id,"message_type":"osm","message_contact_email":"admin@personal.com","message_contact_id":activity.message_contact_id,"message_timestamp":activity.message_timestamp,"message_read":activity.message_read,"message":"Securely share in Data Vault to collaborate with others.", "message_link": "/apps/vault", "message_contact_avatar":activity.message_contact_avatar});
          }
        });
      }

      // internal function for splitting the id and taking what matters
      function parseConnectionData(inputData, real){
        if(typeof real === 'undefined') real = false;
        var followersDataFresh = [];
        angular.forEach(inputData.items, function(follower){
          if((real && follower.metadata.username.length) || !real){
            follower.returnedId = follower.id;
            follower.id = follower.id.split('#')[1];
            followersDataFresh.push(follower);
          }
        });
        return followersDataFresh;
      }

      share.setFollowersToBeLoaded = function(userId, followersFromMetadata){
        share.followersToLoad = followersFromMetadata.map(function(follower){
          return [userId, follower].join('#');
        });
      };

      // get all users to whom this item(gem) was shared
      share.getFollowersData = function(offset){
        if(typeof offset === 'undefined') offset = 0;

        var path = [conf.api.root, conf.api.routes.search].join('');
        var nowLoadTheseFollowers = share.followersToLoad.slice(offset, share.followersPerPage+offset);

        var body = {
          object_type: 'contact',
          id: nowLoadTheseFollowers,
          limit: share.followersPerPage
        };

        var defer = $q.defer();

        $http.post(path, body).success(function(followersDataRaw){
          defer.resolve(parseConnectionData(followersDataRaw));
        })
        .error(function(){
          defer.reject();
        });

        return defer.promise;
      };

      share.searchConnections = function(term, real){

        var axis = (~term.indexOf('@')) ? 'email' : 'username';

        if(typeof real === 'undefined') real = false;

        var body = {
          object_type: 'contact',
          search_metadata: {
            name: term
          }
        };

        body.search_metadata[axis] = term;

        var defer = $q.defer();

        $http({
          url: [conf.api.root, conf.api.routes.search].join(''),
          method: 'POST',
          data: body,
          cache: true
        })
        .success(function(followersDataRaw){
          defer.resolve(parseConnectionData(followersDataRaw, real));
        })
        .error(function(){
          defer.reject();
        });

        return defer.promise;
      };

      share.getAllConnections = function(){
        var defer = $q.defer();

        $http.post([conf.api.root, conf.api.routes.search].join(''), {object_type: 'contact'}).success(function(followersDataRaw){
          defer.resolve(parseConnectionData(followersDataRaw));
        })
        .error(function(){
          defer.reject();
        });

        return defer.promise;
      };

      return share;
    }
  ]
);
