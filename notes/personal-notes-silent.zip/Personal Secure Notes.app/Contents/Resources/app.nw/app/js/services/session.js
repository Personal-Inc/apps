/*global angular:true, is:true, P3Env: true */
angular.module("p3.session",[])
.service('SessionService',['$http', '$location', '$rootScope', '$q', function($http, $location, $rootScope, $q) {
  'use strict';

  //TODO: track error response status, and return proper messages

  var host = $location.protocol() + '://' + $location.host();
  
  // added because on different port it kept hitting the port 80
  if($location.host() == 'localhost') {
    host = host + ':' + $location.port();
  }

  var origin = window.location.origin || window.location.protocol + "//" + window.location.host;
  //TODO: Move allowed apps on expire to config & build;
  var allowedAppsOnExpire = [origin+'/apps/sample'];
  var trackLoginRequests = 0;

  var messages = {
    invalidLogin : "Please try logging in again. Your email address/password did not match our records.",
    expired : "This account has expired. Please go to {{account_settings_link}} and renew subscription.",
    blocked : "This account has been blocked.",
    error : "An Error occurred."
  };


  function noSession(checkedBefore) {
    return {
      state: false,
      timestamp: new Date().getTime(),
      checked: !checkedBefore,
      popupLogin: false
    };
  }

  $rootScope.session = noSession(true);

  var session = {};


  session.trackChanges = function (cb) {
    P3Env.on("sessionChange",function(session) {
      if (!session) $rootScope.session = noSession();
      else {
        angular.extend($rootScope.session, session);
        $rootScope.session.checked = true;
        $rootScope.session.timestamp = new Date().getTime();
        if (session.username) $rootScope.session.state = true;
      }
      $rootScope.$broadcast('sessionChange', $rootScope.session);
      if (cb !== undefined && typeof cb === 'function') cb( $rootScope.session );
    });
  };

  session.login = function (loginData, cb) {
    $http
      .post(host + '/api/v1/session', loginData)
        .success(function (response, status) {
          if (response.username) {
            $rootScope.session.error = undefined;
            $rootScope.session.state = true;
            trackLoginRequests = 0;
            if ($rootScope.session.popupLogin) {
              $rootScope.session.popupLogin.close();
            }
          }
          $rootScope.session.timestamp = new Date().getTime();
          angular.extend($rootScope.session, response);

          if (status === 201) {
            if (!is(response.premium.expired) || is(response.premium.grace) || allowedAppsOnExpire.indexOf(window.location.href)) {
                if (cb !== undefined) cb($rootScope.session);
              } else {
                // console.log('TODO: add this link', messages.expired.replace('{{account_settings_link}}', '<a href="/owner/'+response.username+'/account_settings#premium" target="_top">account settings</a>'));
              }
          }

        })
        .error(function (response, status) {
          if (status === 403 && response.csrf === true) {
            trackLoginRequests++;
            if (trackLoginRequests < 5) {
              session.getSession(function() {
                session.login(loginData, cb);
              });
            }
          } else {
            $rootScope.session.state = false;
            $rootScope.session.timestamp = new Date().getTime();
            if (status == 403 && response.blocked) {
              $rootScope.session.error = messages.blocked;
            }
            else if (status === 401) {
              $rootScope.session.error = messages.invalidLogin;
            }
            else if (status === 400) {
              $rootScope.session.error = messages.error;
            }
            angular.extend($rootScope.session, response);
            if (cb !== undefined) cb($rootScope.session);
          }
        });
  };


  session.isLoggedIn = function () {
    return $rootScope.session.state;
  };

  session.isChecked = function () {
    return $rootScope.session.checked;
  };

  session.isBucket = function () {
    return ($rootScope.session.bucket_mode === true);
  };

  session.setBucketSession = function (session) {
    angular.extend($rootScope.session, session);
    $rootScope.session.state = true;
    $rootScope.session.checked = true;
  };

  session.getSession = function (callback) {
    var deferred = $q.defer();
    var cb = callback || angular.noop;
    $http.get(host + '/api/v1/session')
      .then(
        function (response) {
          angular.extend($rootScope.session, response.data);
          $rootScope.session.state = true;
          $rootScope.session.checked = true;
          if ($rootScope.session.popupLogin) {
            $rootScope.session.popupLogin.close();
          }
          deferred.resolve($rootScope.session);
          return cb($rootScope.session);
        },
        function () {
          if (!$rootScope.session) $rootScope.session = {};
          $rootScope.session.state = false;
          $rootScope.session.timestamp = new Date().getTime();
          $rootScope.session.checked = true;
          deferred.reject($rootScope.session);
          return cb($rootScope.session);
        }
      );
    return deferred.promise;
  };

  session.logout = function (callback) {
    P3Env.endSession();
    $rootScope.session = noSession();
    session.getSession(); // get new csrf token
    var cb = callback || angular.noop;
    cb($rootScope.session);
    // $http.delete(host + '/api/v1/session')
    //   .then( function () {
    //     $rootScope.session = { state: false, timestamp: new Date().getTime(), checked: true, popupLogin: false };
    //     session.getSession();
    //     if (cb !== undefined && typeof cb === 'function') cb( $rootScope.session );
    //   });
  };

  session.refreshCaptcha = function (cb) {
    $http.get('/login/resendCaptcha').then(function (response) {
      if (cb !== undefined && typeof cb === 'function') cb(response.data);
    });
  };

  return session;
}]);