/*global App: true, angular:true */
App.controller('ShareController', ['$scope', '$location', 'conf', '$timeout', '$routeParams', 'HelpersFunctions', 'ShareService', 'TagService', '$log',
    function($scope, $location, conf, $timeout, $routeParams, HelpersFunctions, ShareService, TagService, $log) {

        $scope.shareNote = {};
        $scope.note.followersOffset = 0;
        var stopShareTimer;
        $scope.note.followers = [];
        /*  Following code have been taken from Haka's share_controller */

        // autocomplete for contacts
        $scope.suggestConnections = function(val) {
            return ShareService.searchConnections(val).then(function(response) {
                return response.map(function(connection) {
                    return {
                        name: connection.metadata.name[0],
                        email: connection.metadata.email[0],
                        display: connection.metadata.name[0] + ' (' + connection.metadata.email[0] + ')'
                    };
                });
            });
        };

        $scope.loadShareData = function() {
            // fetch persons with whom this gem has been shared
            if (typeof $scope.note.follower === 'undefined') $scope.note.follower = [];
            $scope.note.loadingShare = true;
            $scope.note.totalFollowers = $scope.note.follower.length;
            ShareService.setFollowersToBeLoaded($scope.note.owner, $scope.note.follower);
            ShareService.getFollowersData().then(function(followersData) {
                $scope.note.followers = followersData;
                $scope.note.loadingShare = false;
            });
        };

        $scope.goShareNote = function() {
            $scope.note.sharingNote = true;

            if (typeof $scope.shareNote !== 'undefined') {
                $scope.shareNote.addingShare = false;
                if ($scope.shareNote.emailAddress !== '' && typeof $scope.note.followers !== 'undefined') {
                    var flatFollowersEmails = $scope.note.followers.map(function(follower) {
                        return follower.metadata.email[0];
                    });
                    var flatFollowersUsernames = $scope.note.followers.map(function(follower) {
                        if (follower.metadata.username) return follower.metadata.username[0];
                    });
                    if ((~$scope.shareNote.emailAddress.indexOf('@') && !~flatFollowersEmails.indexOf($scope.shareNote.emailAddress)) || (!~$scope.shareNote.emailAddress.indexOf('@') && !~flatFollowersUsernames.indexOf($scope.shareNote.emailAddress))) {
                        $scope.shareNote.addingShare = true;
                        ShareService.startShare([$scope.note.id], ['read'], [$scope.shareNote.emailAddress]).success(function() {
                            var followerSearchTerm = angular.copy($scope.shareNote.emailAddress);

                            if (typeof $scope.shareNoteData === 'undefined') $scope.shareNoteData = {};

                            $scope.shareNoteData[followerSearchTerm] = {
                                id: '-',
                                metadata: {
                                    email: [$scope.shareNote.emailAddress],
                                    name: [$scope.shareNote.emailAddress]
                                },
                                newlyAdded: true,
                                loading: true
                            };

                            $scope.sharingNote = false;
                            $scope.shareNote.error = null;

                            // pushing the new follower
                            $scope.note.followers.unshift($scope.shareNoteData[followerSearchTerm]);
                            $scope.totalFollowers++;

                            // resetting input data
                            $scope.shareNote.emailAddress = '';
                            $scope.shareNote.addingShare = false;

                            // this timeout is because a metadata worker does not crunch data fast enough...
                            $timeout(function() {
                                ShareService.searchConnections(followerSearchTerm).then(function(data) {
                                    var lastSharedIndex = $scope.note.followers.indexOf($scope.shareNoteData[followerSearchTerm]);
                                    $scope.note.followers[lastSharedIndex].loading = false;

                                    if (typeof data[0] !== 'undefined') {
                                        // update the "fake" model
                                        var axis = (~followerSearchTerm.indexOf('@')) ? 'email' : 'username';
                                        angular.forEach(data, function(contact) {
                                            if (contact.metadata[axis][0] == followerSearchTerm) {
                                                $scope.note.followers[lastSharedIndex] = contact;
                                                $scope.note.follower.unshift(contact.id);
                                            }
                                        });

                                        // this is due to animation purposes, I need a flag on newly added fields, and then have it removed later on
                                        $scope.note.followers[lastSharedIndex].newlyAdded = false;
                                    }
                                });
                            }, 5000);
                        }).error(function() {
                            $scope.shareNote.error = 'An error occurred, please correct input and try again.';
                            $scope.shareNote.addingShare = false;
                        });
                    } else {
                        $scope.shareNote.error = 'Gem is already shared with this user.';
                        $scope.shareNote.addingShare = false;
                    }
                }
            }

        };

        $scope.loadShare = function() {
            if ($scope.note.shareContainerLoaded === true) {
                $scope.note.loadShareContainer = null;
                $scope.note.shareContainerLoaded = null;
            } else {
                $scope.note.loadShareContainer = true;
                $scope.note.shareContainerLoaded = true;
                $timeout(function() {
                    $scope.note.loadShareContainer = false;
                }, 2000);
            }

        };

        $scope.stopShareAlert = function(follower) {
            $scope.note.followers[$scope.note.followers.indexOf(follower)].stopShareAlert = true;
            stopShareTimer = $timeout(function() {
                $scope.note.followers[$scope.note.followers.indexOf(follower)].stopShareAlert = false;
            }, 4000);
        };

        // stop share and remove the follower from the list
        $scope.stopShare = function(follower) {
            $timeout.cancel(stopShareTimer);
            follower.stoppingShare = true;
            ShareService.stopShare($scope.note.owner, conf.profile_template, $scope.note.id, follower.id).success(function() {
                $scope.note.followers.splice($scope.note.followers.indexOf(follower), 1);
                $scope.note.follower.splice($scope.note.follower.indexOf(follower.id), 1);
                $scope.note.totalFollowers--;
                $timeout(function() {
                    follower.stoppingShare = false;
                }, 1000);
            });
        };

    }
]);