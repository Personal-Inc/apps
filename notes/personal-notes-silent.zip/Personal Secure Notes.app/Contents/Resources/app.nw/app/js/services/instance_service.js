/*global  angular: true */
angular.module('p3.gems')
.service('InstanceService',
  [
    '$http',
    'conf',
    '$log',
    function($http, conf, $log) {
      'use strict';

      var instance = {};

      instance.fetchSemanticSchema = function(){
        var path = [conf.static.root, conf.static.routes.semantic].join('');
        return $http({
          url: path,
          method: 'GET',
          cache: true
        });
      };

      // fetch all options (currently just first 100, MAYBE should do this thing recursively)
      instance.fetchOptionsFromSource = function(source){
        return hitAutocompleteApi(source + '/autocomplete?limit=100');
      };

      // suggest options from autocomplete based on typed keyword
      instance.suggestOptionsFromSource = function(source, term){
        return hitAutocompleteApi(source + '/autocomplete?q='+term);
      };

      // Save a single instance, provided ID and value for it
      instance.saveInstance = function(instanceId, value, opts){
        var path = [conf.api.root, conf.api.routes.data].join('');
        var saveData = {data: {}};
        if(typeof opts !== 'undefined'){
            saveData.context = {};
            var context_name = instanceId.split(".")[0];
            saveData.context[context_name] = opts.context;
        }
        saveData.data[instanceId] = value;
        return $http({
          url: path,
          method: "POST",
          data: saveData
        });
      };

      // save multiple instances, provided object of key-values for them
      instance.saveInstances = function(instancesToSave){
        var path = [conf.api.root, conf.api.routes.data].join('');
        return $http({
          url: path,
          method: "POST",
          data: {data: instancesToSave}
        });
      };

      instance.getInstance = function(instanceId){
        var path = [conf.api.root, conf.api.routes.profiles].join('');
        return $http({
          url: path,
          method: "POST",
          data: {
            "include": "value",
            "field_instance": instanceId
          }
        })
        .then(function(returned){
          return returned.data[Object.keys(returned.data)[0]].value;
        });
      };

      return instance;

      ////////////////

      function hitAutocompleteApi(url){
        return $http({
          url: url,
          method: 'GET',
          cache: true
        });
      }
    }
  ]
);