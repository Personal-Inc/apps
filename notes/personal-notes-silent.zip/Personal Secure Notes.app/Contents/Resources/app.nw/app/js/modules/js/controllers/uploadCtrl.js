angular.module('p3.attachments')
.controller('uploadCtrl', function($scope, $log, conf, FileUploader, AttachmentService){

	  // function calculateFreePercentage(){
	  //   $scope.fileService.status.percentFree = parseInt(($scope.fileService.status.storage.used_space / $scope.fileService.status.storage.storage_limit) * 100);
	  // }

	  var filesUploading = [];

	  // get initial file service status
	  if(!$scope.fileService.status){
		AttachmentService.getStatus().success(function(status){
		  $scope.fileService.status = status;
		  $scope.fileService.status.spaceFree = $scope.fileService.status.storage.storage_limit;
		  // calculateFreePercentage();
		});
	  }

	  // Initial config of file uploader
	  var uploader = $scope.item.uploader = new FileUploader({
		url: conf.files.root+conf.files.routes.file+'?gem_id='+encodeURIComponent([$scope.ownerId, $scope.item.metadata.profile_template[0], $scope.item.id].join('#')),
		autoUpload: true,
		alias: 'files[]',
		queueLimit: 10,
		filters: [{
		  // check if file size is compliant with users limits
		  name: 'sizeLimit',
		  fn: function(item){
			return (item.size < $scope.fileService.status.storage.file_size_limit && item.size < $scope.fileService.status.storage.free_space);
		  }
		}]
	  });

	  if($scope.item.id < 0){
		$scope.$watch('item.id', function(id){
		  uploader.url = conf.files.root+conf.files.routes.file+'?gem_id='+encodeURIComponent([$scope.ownerId, $scope.item.metadata.profile_template[0], $scope.item.id].join('#'));
		});
	  }

	  uploader.onSuccessItem = function(fileItem, response) {
		$scope.item.attachments.unshift({
		  id: response.id,
		  fileIcon: $scope.fileService.getIconFromMimeType($scope.fileService.globalFiletypes.mimetypes[response['mime-type']], response['name'].split('.').pop()),
		  name: response.name,
		  size: response.size
		});
		$scope.fileService.status.storage.used_space += response.size;
		// calculateFreePercentage();
		filesUploading.splice(filesUploading.indexOf(fileItem));
		fileItem.remove();
	  };

	  uploader.onBeforeUploadItem = function(fileItem) {
		$scope.generalAttachmentError = null;
		filesUploading.push(fileItem);
	  };

	  uploader.onErrorItem = function(fileItem, response) {
		fileItem.errorText = response.error_description;
		filesUploading.splice(filesUploading.indexOf(fileItem));
	  };

	  uploader.onWhenAddingFileFailed = function(item, filter){
		if(filter.name === 'sizeLimit'){
		  $scope.generalAttachmentError = 'You do not have enough space to store this file or it is too large';
		}
		else {
		  $scope.generalAttachmentError = 'Error occurred while trying to attach this file';
		}
	  };

	$scope.$watch('item.deleting', function(deleting){
		if(deleting){
			angular.forEach(filesUploading, function(fileUploading){
				fileUploading.cancel();
			});
		}
	});
});