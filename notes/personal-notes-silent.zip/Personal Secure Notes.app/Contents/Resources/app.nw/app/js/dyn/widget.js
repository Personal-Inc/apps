(function (d, appOrigin, appId) {
    var h = d.getElementsByTagName('head')[0];
    var s = d.createElement('script');
    s.src = appOrigin + "/apps/_/engine/" + appId + "/bootstrap.js?" + new Date().getTime();
    s.type = 'text/javascript';
    h.appendChild(s);
})(window.document, "@@host", "@@appId");