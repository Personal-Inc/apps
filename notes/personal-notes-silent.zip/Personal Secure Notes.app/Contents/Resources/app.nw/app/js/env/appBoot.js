
(function(w, $) {
    "use strict";
    var nextApp; // TODO better binding of appId - this is limited to one concurrent boot
    var events = {};
    var appConfig = {};
    var contextAppName = w.self.location.pathname.match(/apps\/(.*?)\//)[1] || w.self.location.pathname.match(/apps\/(.*)\/?/)[1];
    var isIframeContext = (contextAppName === 'login') ? false : w.self !== w.top;
    w.P3Env = {
        isIframeContext : isIframeContext,
        contextAppName : contextAppName,
        loadTimestamp : new Date().getTime(),
        boot : function() {
            var appId = nextApp;// TODO better binding of appID
            boot(appId,{isIframe: w.P3Env.isIframeContext});
        },
        init : function(){
            boot(w.P3Env.contextAppName,{isIframe: w.P3Env.isIframeContext});
            $("body").toggleClass("p3-app-iframed", w.P3Env.isIframeContext);
        },
        on : function(eventType, callback){
            var e = events[eventType];
            if (e) {
                e.observers.push(callback);
                if (e.observers.length == 1) {
                    e.init(function(event) {
                        handleEvent(eventType, event);
                    });
                }
            }
        },
        config : function(settings){
            $.extend(appConfig,settings);
            return appConfig;
        },
        registerEventProvider : function(eventType, init) {
            // TODO : exception if already initialized
            if (events[eventType] !== undefined) {
                throw "Event provider '" + eventType + "' already registered";
            }
            events[eventType] = {
              observers : [],
              init : init
            };
        }
    };

    function handleEvent(eventType, event) {
        if (events[eventType]){
            var o = events[eventType].observers;
            for (var i = 0, l = o.length; i < l; i++) {
                o[i](event);
            }
        }
    }

    $(function(){
        w.P3Env.init();
    });

    var clientWindow;
    var clientOrigin;
    var channel;
    var channelQueues = { outbox : [], inbox : [] };
    var clientSessions = {};
    // TODO multi clients ?
    $(w).bind("message", function(ev){
        var e = ev.originalEvent;
        // ignore init requests if already initialized
        var packet = JSON.parse(e.data);
        packet.origin = ev.originalEvent.origin;

        if (packet.init && clientWindow) {
            return;
        }
        if (packet.session === undefined) {
            return;
        }

        if (packet.init) {
            clientWindow = e.source;
            clientOrigin = e.origin;
            channel = packet.init;
            $.get("/apps/_/engine/channel_session_token", {
                random : packet.session.random
            }).done(function(r){
                if (r.token == packet.session.token) {
                    clientSessions[channel] = packet.session;
                    sendMessage({
                        ack : channel
                    });
                    flushChannelInbox();
                    flushChannelOutbox();
                    handleMessages();
                }
            });

        } else if (packet.type !== undefined && packet.message !== undefined) {
            if (packet.channel !== undefined && channel === undefined) {
                // channel is still not set, but got message with channel specified
                // so need to keep this message until channel is defined
                channelQueues.inbox.push(packet);
            } else if (packet.channel !== undefined && channel !== undefined && packet.channel == channel) {
                receiveMessage(packet);
            }
        }
    });

    function flushChannelInbox(){
        for (var i = 0, l = channelQueues.inbox.length; i < l; i++){
            var packet = channelQueues.inbox[i];
            if (packet.channel !== channel) continue;
            receiveMessage(packet);
        }
    }

    function flushChannelOutbox(){
        for (var i = 0, l = channelQueues.outbox.length; i < l; i++){
            var packet = channelQueues.outbox[i];
            packet.channel = channel;
            sendMessage(packet);
        }
    }

    var outgoingQueue = [];
    function sendMessage(m) {
        outgoingQueue.push(m);
        if (clientWindow){
            for (var i = 0, l = outgoingQueue.length; i < l; i++){
                var msg = JSON.stringify(outgoingQueue[i]);
                clientWindow.postMessage(msg, clientOrigin);
            }
            outgoingQueue = [];
        }
    }

    var clientMessages = {};
    var clientMessageHandlers = {};
    function receiveMessage(packet){
        if (!validSession(packet)) {
            return;
        }
        var type = packet.type;
        // TODO cleaning up messages in queue with no handler defined ?
        if (clientMessages[type] === undefined) {
            clientMessages[type] = [];
        }
        clientMessages[type].push({message: packet.message, origin: packet.origin});
        handleMessages(type);
    }

    function validSession(packet){
        var channelSession = clientSessions[packet.channel];
        return channelSession && channelSession.token == packet.session.token;
    }

    function handleMessages(type){
        if (type === undefined){
            for (var t in clientMessages){
                if (clientMessages.hasOwnProperty(t)){
                    handleMessages(t);
                }
            }
        } else {
            var handler = clientMessageHandlers[type];
            var messages =  clientMessages[type];
            if (handler && messages){
                for(var i = 0, l = messages.length; i < l; i++){
                    handler(messages[i].message, {origin: messages[i].origin});
                }
                clientMessages[type] = [];
            }
        }
    }

    function appRunnerName(appId) {
        return $.camelCase("run-" + appId);
    }

    function boot(appId, segments) {
        segments = segments || {};
        segments.app  = w.P3Apps[appId];
        var context = {
            container : segments.container,
            client : {
                sendMessage : function(type, m){
                    var data = { app : appId, channel : channel, type : type, message : m };
                    if (channel === undefined){
                        channelQueues.outbox.push(data);
                    } else {
                        sendMessage(data);
                    }
                },
                onMessage : function(type, cb){
                    clientMessageHandlers[type] = cb;
                    handleMessages(type);
                }
            },
            isIframe: w.P3Env.isIframeContext
        };
        segments.app.init(context);
        w.P3Env[appRunnerName(appId)] = segments.app.run;
        segments.app.run();
    }


})(window, window.jQuery);