/*global App: true, angular:true */
App.controller('LoginController', ['$scope', '$location', '$window', 'SessionService', '$rootScope',
    function($scope, $location, $window, SessionService, $rootScope) {
        'use strict';
        $scope.submitLogin = function() {

            var login = {};
            angular.element('.loading-icon').show();
            $scope.errorMessage = '';


            login.email = $scope.loginEmail ? $scope.loginEmail : angular.element('#email').val();
            login.password = $scope.loginPwd ? $scope.loginPwd : angular.element('#password').val();
            login.persist = true;

            if ($scope.showCaptcha) {
                login.captcha = {
                    id: $scope.captchaId,
                    answer: $scope.captchaAnswer
                };
            }
            $scope.loader = true;
            SessionService.login(login, function(response) {
                $scope.loader = false;
                $scope.closeError();
                if (response.state === true) {
                    SessionService.getSession(function(state) {
                        $location.path("/browse");
                        angular.element('.loading-icon').hide();
                    });
                } else if (response.captcha !== undefined) {
                    $scope.showCaptcha = true;
                    $scope.captchaId = response.captcha.id;
                    $scope.captchaQuestion = response.captcha.question;
                    $scope.loginPwd = '';
                    angular.element('.loading-icon').hide();
                    $scope.errorMessage = response.error;
                    angular.element('#password').focus();
                } else if (response.error !== undefined) {
                    $scope.errorMessage = response.error;
                    $scope.loginPwd = '';
                    angular.element('.loading-icon').hide();

                    angular.element('#password').focus();
                }
            });

        };

        function isNative() {
            if (typeof require !== 'undefined') {
                return true;
            } else {
                return false;
            }
        }

        $scope.openLink = function(url) {
            if (isNative()) {
                var gui = require('nw.gui');
                return gui.Shell.openExternal(url);
            } else {
                $window.open(url, '_blank');
            }
        };

        $scope.captchaRefresh = function() {
            $scope.captchaLoader = true;
            SessionService.refreshCaptcha(function(response) {
                $scope.captchaLoader = false;
                $scope.captchaId = response.guid;
                $scope.captchaQuestion = response.question;
                $scope.showCaptcha = true;
            });
        };

        $scope.closeError = function() {
            $scope.errorMessage = false;
        };

        $scope.logout = function() {
            $scope.closeError();
            $rootScope.session.state = false;
            SessionService.logout(function(session) {
                $rootScope.session = session;
            });
        };

    }
]);