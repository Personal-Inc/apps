/*global App: true */
if (App.isNative === true){
angular.module('app')
    .provider('myCSRF', [function() {
        var headerName = 'X-CSRF-Token';
        var cookieName = 'csrftoken';
        var allowedMethods = ['GET'];
        this.$get = ['$cookies', function($cookies) {
            return {
                'request': function(config) {
                    if (allowedMethods.indexOf(config.method) === -1) {
                        // do something on success
                        config.headers[headerName] = $cookies[cookieName];
                    }
                    return config;
                }
            };
        }];
    }])
    .config(
        [
            '$httpProvider',
            function($httpProvider) {
                $httpProvider.interceptors.push('myCSRF');
            }
        ]
    );
}
angular.module('app')
    .run(function($window, $rootScope) {
        $rootScope.online = navigator.onLine;
        $window.addEventListener("offline", function() {
            $rootScope.$apply(function() {
                $rootScope.online = false;
            });
        }, false);
        $window.addEventListener("online", function() {
            $rootScope.$apply(function() {
                $rootScope.online = true;
            });
        }, false);
    })
    .run(['$route', '$rootScope', '$location', 'conf', function($route, $rootScope, $location, conf) {
        var original = $location.path;
        $location.path = function(path, reload) {
            if (reload === false) {
                var lastRoute = $route.current;
                var un = $rootScope.$on('$locationChangeSuccess', function() {
                    $route.current = lastRoute;
                    un();
                });
            }
            return original.apply($location, [path]);
        };
        // change config to reflect running environment dynamically
        conf.appjs = typeof require !== 'undefined';
        if(typeof require !== 'undefined'){
            conf.api.root = 'https://www.personal.com/api/v1/';
            conf.files.root = 'https://www.personal.com/';
            conf.static.root = 'https://www.personal.com/s/';
        }
        else {
            conf.api.root = '/api/v1/';
        }
    }])
    .config(['$provide', function($provide){
        $provide.decorator('taOptions', ['$delegate', function(taOptions){
            taOptions.toolbar = [
                ['bold', 'italics', 'underline']
            ];
            taOptions.classes = {
                focussed: 'focussed',
                toolbar: 'btn-toolbar',
                toolbarGroup: 'btn-group',
                toolbarButton: 'btn btn-default no-radius',
                toolbarButtonActive: 'active',
                disabled: 'disabled',
                textEditor: 'form-control no-radius',
                htmlEditor: 'form-control no-radius'
            };
            return taOptions;
        }]);
        
    }])
    .constant('conf', {
        portalPath: 'https://www.personal.com',
        profile_template: '0175',
        resend_captcha: '/login/resendCaptcha',
        gemName: 'gems:files photos & top secret notes',
        headerTitle: 'My Secure Notes',
        api: {
            root: '/api/v1/',
            routes: {
                search: 'metadata/browse/',
                metadata: 'metadata/',
                profiles: 'data/browse',
                gems: 'gems/',
                share: 'share/',
                authencityToken: 'authorization/',
                session: 'session',
                resend_captcha: '/',
                data: 'data',
                messages: 'messages',
                activityCount: 'owner/_/messages_count'
            }
        },
        files: {
            root: '/',
            routes: {
                file: 'file',
                fileservice: 'fileservice/',
                status: 'status',
                fileCheck: 'check/queue/'
            }
        },
        static: {
            root: '/s/',
            routes: {
                semantic: 'assets/data/semantic.json',
                filetypes: 'assets/data/filetypes.json'
            }
        },
        withCredentials: true
    });