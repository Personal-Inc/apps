/*global App: true, angular:true */
App.controller('HeaderController', ['$scope', 'conf', '$http', '$location', 'SessionService', '$rootScope', '$timeout',
    function($scope, conf, $http, $location, SessionService, $rootScope, $timeout) {
        'use strict';
        $scope.logoutShow = false;
        $scope.offlineMode = false;
        $scope.authenticated = null;
        $scope.showWindowControl = true;
        $scope.homeUrl = $location.path();
        var session_service = SessionService;
        var logoutTimer;

        if (navigator.appVersion.indexOf("Win") != -1) {
            $scope.showWindowControl = false;
        }

        $scope.versionCheck = function() {
            // Check for new version
            $http.get('http://personal-inc.github.io/apps/notes/package.json?t=' + $.now()).
            success(function(data, status, headers, config) {
                $scope.newVersion = data.version;
                $scope.newVersionUrl = data.packages.mac.url;
                $http.get('package.json').
                success(function(data, status, headers, config) {
                    $scope.currentVersion = data.version;
                    // console.log($scope.newVersion, $scope.currentVersion);
                    if ($scope.newVersion > $scope.currentVersion) {
                        $('#version').removeClass('hide');
                        $('#version a').attr('url', $scope.newVersionUrl);
                    }
                });
            });
        };

        $scope.logoutAlert = function() {
            $scope.logoutShow = true;
            logoutTimer = $timeout(function() {
                $scope.logoutShow = false;
            }, 5000);
        };

        $scope.logout = function() {
            $timeout.cancel(logoutTimer);
            $rootScope.session.state = false;
            SessionService.logout(function(session) {
                $rootScope.session = session;
                $location.path('/');
            });
        };

        // switching between online/offline mode automatically
        $scope.$watch('online', function() {
            if ($rootScope.online === false) {
                $scope.offlineMode = true;
                $location.path('/offline');
            } else if ($rootScope.online === true) {
                $scope.offlineMode = false;
                if ($rootScope.fromOffline === true) {
                    $location.path('/');
                }
            }
        });

        // session checking here 
        SessionService.getSession(function(state) {
            if (state.state === true) {
                $scope.username = $rootScope.session.username;
                $scope.authenticated = true;
                if ($location.path() == '/') {
                    $location.path('/browse');
                }
            } else if ($scope.offlineMode) {
                $location.path('/offline');
                $scope.offlineNotes = storedb('notes').find();
                $rootScope.offlineNotes = $scope.offlineNotes;

            } else {
                $location.path('/');
            }
        });

        if (conf.appjs) {
            $scope.versionCheck();
        }

    }
]);