angular.module('p3.attachments')
.directive('attachmentsUpload', function($log){
	return {
		restrict: 'A',
		templateUrl: 'js/modules/js/views/upload.html',
		controller: 'uploadCtrl',
		scope: {
			item: '=linkedItem',
			ownerId: '=ownerId',
			fileService: '=fileService'
		}
	};
});