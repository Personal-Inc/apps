function openDevTools() {
    return gui.Window.get().showDevTools();
}

if (typeof require !== 'undefined') {
    var gui = require('nw.gui');

    win = gui.Window.get();
    win.isMaximized = false;

    var nativeMenuBar = new gui.Menu({
        type: "menubar"
    });
    try {
        nativeMenuBar.createMacBuiltin("My App");
        win.menu = nativeMenuBar;
    } catch (ex) {}

    var tray = new gui.Tray({
        icon: 'app/images/icon/small.png'
    });


    win.on('close', function() {
        this.hide(); // Pretend to be closed already
        this.close(true);
    });

    $(function() {
        function Menu(cutLabel, copyLabel, pasteLabel) {
            var gui = require('nw.gui'),
                menu = new gui.Menu(),

                copy = new gui.MenuItem({
                    label: copyLabel || "Copy",
                    click: function() {
                        document.execCommand("copy");
                    }
                }),

                paste = new gui.MenuItem({
                    label: pasteLabel || "Paste",
                    click: function() {
                        document.execCommand("paste");
                    }
                });

            menu.append(copy);
            menu.append(paste);

            return menu;
        }

        var menu = new Menu( /* pass cut, copy, paste labels if you need i18n*/ );
        $(document).on("contextmenu", function(e) {
            e.preventDefault();
            menu.popup(e.originalEvent.x, e.originalEvent.y);
        });
    });



}


$(document).ready(function() {
    $('.openWindow').on('click', function() {
        var url = $(this).attr('url');
        require('nw.gui').Shell.openExternal(url);
    });
});