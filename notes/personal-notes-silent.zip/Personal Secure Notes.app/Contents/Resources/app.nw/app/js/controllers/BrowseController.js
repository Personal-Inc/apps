/*global App: true, angular:true */
App.controller('BrowseController', ['$scope', '$rootScope', '$routeParams', '$route', '$location', 'conf', '$filter', '$timeout', 'SessionService', 'InstanceService', 'SearchService', 'ItemService', 'HelpersFunctions', 'TagService', '$sanitize',
    function($scope, $rootScope, $routeParams, $route, $location, conf, $filter, $timeout, SessionService, InstanceService, SearchService, ItemService, HelpersFunctions, TagService, $sanitize) {
        'use strict';

        $scope.searchObj = {};
        $scope.searchObj.offset = 0;
        $scope.noteDeleted = false;
        $scope.loadingNote = false;
        $scope.noteContainer = null;
        $rootScope.noteDeleted = false;
        $scope.addTagOn = false;
        $scope.notes = [];
        $scope.note = {};
        $rootScope.fromOffline = false;
        $scope.shareContainerLoaded = false;
        $scope.ftux = false;
        $scope.leftToLoad = 10;
        if (typeof $scope.fileService === 'undefined') $scope.fileService = {};

        // Calling different functions as route changes
        $scope.$watch('$locationChangeStart', function(event) {
            if ($location.path() == '/add-note') {
                $scope.headerTitle = 'Add note';
                $scope.addNew();
                $scope.deleteConfirmed = false;

                $scope.ftux = true;
            } else if ($location.path() == '/browse') {

                $scope.showLoading = true;
                $scope.headerTitle = conf.headerTitle;

            } else if ($location.path() !== '/timeline') {
                $scope.note_obj = {
                    id: $routeParams.id,
                    loaded: false
                };
            }
            $scope.showLoading = true;
        });

        $rootScope.$watch('noteDeleted', function() {
            $scope.noteDeleted = $rootScope.noteDeleted;
            $scope.noteContainer = null;
        });

        $scope.$watch('noteContainer', function() {
            if ($scope.noteContainer == 'edit') {
                $scope.note.oldValueTitle = $scope.note.title;
                $scope.note.oldValueBody = $scope.note.body;
            }
        });

        // search
        $scope.search = function(term) {
            if (typeof term === 'undefined') term = '*';
            $scope.searching = true;
            SearchService.search(term, $scope.searchObj.offset, 'updated_timestamp', {
                    metadata: {
                        profile_template: '0175'
                    }
                })
                .then(function(filteredResponse) {
                        $scope.errorBrowseNotes = false;
                        $scope.searching = false;
                        // Sync offline data
                        $scope.showLoading = false;
                        if (storedb('notes').find()) {
                            var offlineNotes = storedb('notes').find().reverse();
                            angular.forEach(offlineNotes, function(note) {
                                var opts = {};
                                opts.context = {
                                    'name': note.title
                                };
                                $timeout(function() {
                                    InstanceService.saveInstance('new0.secure_note_note', note.body, opts)
                                        .success(function(data) {
                                            var new_note = {
                                                'id': Object.keys(data.data)[0],
                                                'title': note.title,
                                                'owner': $rootScope.session.user_id,
                                                'timestamp': note.timestamp
                                            };
                                            $scope.notes.push(new_note);
                                            storedb('notes').remove({
                                                "_id": note._id
                                            });
                                        });
                                }, 2000);
                            });
                        }
                        $scope.allTags = Object.keys(filteredResponse.facets.tag);
                        $scope.notes = HelpersFunctions.prepareNotes(filteredResponse.items);

                        SearchService.notes = $scope.notes;

                        if (typeof $scope.note_obj !== 'undefined') {
                            $scope.getNote($scope.note_obj, true);
                        }

                        if ($location.path() === '/timeline') {
                            $scope.timeline = HelpersFunctions.groupNotes($scope.notes, 'date_final');
                        }
                        if ($scope.notes.length) {
                            $scope.ftux = true;
                        }
                        $scope.notes.total = filteredResponse.total;
                        if (($scope.notes.total - $scope.notes.length) < 10) {
                            $scope.leftToLoad = $scope.notes.total - $scope.notes.length;
                        }
                        if ($location.path() === '/browse' && $scope.searchNote !== 'undefined' && $scope.notes.length > 0) {
                            $scope.note_obj = {
                                id: $scope.notes[0].id,
                                loaded: false
                            };
                            $scope.getNote($scope.note_obj, true);
                        }
                    },
                    function(error) {
                        $scope.searching = false;
                        $scope.showLoading = false;
                        $scope.errorBrowseNotes = true;
                        $scope.ftux = true;
                    });
        };
        // initial browse request
        $scope.search(undefined);

        // watching for search term
        $scope.$watch('searchNote', function(term) {
            $timeout.cancel($scope.searchTimer);
            if (typeof term !== 'undefined') {
                $scope.searchObj.offset = 0;
                $scope.searchTimer = $timeout(function() {
                    $scope.search(term);
                }, 500);
            }
        });

        $scope.loadMore = function() {
            $scope.loadingMore = true;
            $scope.searchObj.offset += SearchService.perPage;
            SearchService.search(conf.gemName, $scope.searchObj.offset)
                .then(function(filteredResponse) {
                    $scope.loadingMore = false;
                    var loadMore = HelpersFunctions.prepareNotes(filteredResponse.items);
                    $scope.notes = _.union($scope.notes, loadMore);

                    if ($location.path() === '/timeline') {
                        $scope.timeline = HelpersFunctions.groupNotes($scope.notes, 'date_final');
                    }
                    $scope.notes.total = filteredResponse.total;


                    if (($scope.notes.total - $scope.notes.length) < 10) {
                        $scope.leftToLoad = $scope.notes.total - $scope.notes.length;
                    }

                });
        };

        $scope.refresh = function() {
            $route.reload();
        };

        $scope.getNote = function(note_obj, ext) {
            $scope.loadingNote = true;
            $scope.noteDeleted = false;
            $scope.note.addTagOn = false;
            $scope.note.shareContainerLoaded = null;
            $scope.deleteConfirmed = false;
            $scope.shareNote = null;
            $scope.headerTitle = conf.headerTitle;

            SessionService.getSession(function(state) {
                if (state.state === false) {
                    $location.path('/');
                }
            });
            if (note_obj.loaded) {
                $scope.note = note_obj;
                $scope.loadingNote = false;
                afterGetNote();
            } else {
                if (ext) {
                    SearchService.search('gem:' + $scope.note_obj.id)
                        .then(function(filteredResponse) {
                                $scope.note = HelpersFunctions.prepareNotes(filteredResponse.items)[0];
                                ItemService.getItem($scope.note_obj.id).then(function(instanceData) {
                                    $scope.note.body = instanceData[1].value.replace(/\n/g, '<br>');
                                    $scope.note.loaded = true;
                                    $scope.loadingNote = false;
                                    $scope.note.myGem = ($scope.note.owner == $rootScope.session.user_id);
                                    afterGetNote(ext);
                                });
                            },
                            function(error) {
                                $scope.searching = false;
                            });
                } else {
                    $scope.note = note_obj;
                    $scope.currentId = $scope.note.id;
                    ItemService.getItem($scope.note.id).then(function(instanceData) {
                        $scope.note.body = instanceData[1].value.replace(new RegExp('\r?\n', 'g'), '<br />');
                        $scope.note.loaded = true;
                        $scope.loadingNote = false;
                        $scope.note.myGem = ($scope.note.owner == $rootScope.session.user_id);
                        afterGetNote();
                    });
                }
            }

        };

        function afterGetNote(ext) {
            if (!ext) {
                $location.path("/note/" + $scope.note.id, false);
            }
            $scope.autocomplete_data = _.difference($scope.allTags, $scope.note.tag);
            $scope.currentTimestamp = $scope.note.timestamp;
            $scope.currentId = $scope.note.id;
            $scope.noteContainer = 'show';
        }

        $scope.detachTag = function(tag, note) {
            TagService.detachTag(tag, note.id).then(function() {
                $scope.note.tag.splice($scope.note.tag.indexOf(tag), 1);
            });
        };

        $scope.addNew = function(seed) {
            if (typeof seed === 'undefined') seed = '';
            $scope.currentId = null;
            $scope.currentTimestamp = null;
            $scope.noteDeleted = false;
            $scope.noteContainer = 'add';
            $scope.note = {
                body: seed
            };
        };

        $scope.cancel = function() {
            if ($scope.noteContainer == 'edit') {
                $scope.note.title = $scope.note.oldValueTitle;
                $scope.note.body = $scope.note.oldValueBody;
            } else {
                $scope.note = {};
            }
            $scope.noteContainer = 'show';
            $location.path("/browse", false);
            $scope.headerTitle = conf.headerTitle;
        };

        $scope.saveNote = function() {
            saveNote('new0');
        };

        $scope.editNote = function(param) {
            if (typeof param !== 'undefined') {
                saveNote($scope.currentId);
            } else {
                $scope.noteContainer = 'edit';
            }
        };

        $scope.isMyGem = function(note) {
            return (note.owner == $rootScope.session.user_id);
        };

        function saveNote(id) {
            var opts = {};
            opts.context = {
                'name': $scope.note.title
            };
            $scope.errorTitle = false;
            $scope.note.body = $sanitize($scope.note.body);
            ItemService.invalidateCachedItem(id);
            InstanceService.saveInstance(id + '.secure_note_note', $scope.note.body.replace(new RegExp('\r?\n', 'g'), '<br />'), opts)
                .success(function(response) {
                    $scope.ftux = true;
                    $scope.errorTitle = false;
                    if (id === 'new0') {
                        id = Object.keys(response.data)[0];
                        var new_note = {
                            'id': id,
                            'title': $scope.note.title,
                            'body': $scope.note.body.replace(new RegExp('\r?\n', 'g'), '<br />'),
                            'owner': $rootScope.session.user_id,
                            'timestamp': event.timeStamp,
                            'attachments': [],
                            'loaded': true,
                            'metadata': {
                                'profile_template': ['0175']
                            }
                        };
                        $scope.notes.push(new_note);
                        $scope.note_obj = new_note;
                        $scope.getNote(new_note, true);

                    } else {
                        var findNotesId = HelpersFunctions.objIndexOf($scope.notes, id);
                        $scope.notes[findNotesId].title = $scope.note.title;
                        $scope.notes[findNotesId].body = $scope.note.body.replace(new RegExp('\r?\n', 'g'), '<br />');
                        $scope.notes[findNotesId].timestamp = event.timeStamp;
                        $scope.notes.loaded = true;
                    }
                    $scope.notes.total++;
                    $scope.currentId = id;
                    $scope.currentTimestamp = event.timeStamp;
                    $scope.noteContainer = 'show';
                    $location.path("/browse", false);
                })
                .error(function(error) {
                    $scope.errorTitle = true;
                });
        }

    }
]);