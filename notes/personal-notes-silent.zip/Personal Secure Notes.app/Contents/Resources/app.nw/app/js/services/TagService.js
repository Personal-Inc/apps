/*global angular:true, is:true, console: true */
App.service('TagService', ['$http', 'conf', function($http, conf) {
    'use strict';

    var tag = {};
    var opts = {
        withCredentials: conf.withCredentials,
        cache: true
    };


    tag.addTag = function(object_type, metadata_param, guid) {
        var path = [conf.api.root, conf.api.routes.metadata, guid].join('');
        return $http.put(path, {
                "object_type": object_type,
                "metadata": metadata_param,
                "limit": 100
            }, opts)
            .then(function(response) {
                return response.data;
            }, function(response) {
                return response.status;
            });
    };

    tag.detachTag = function(tagToRemove, guid) {
        var path = [conf.api.root, conf.api.routes.metadata, guid].join('');
        return $http({
                method: 'DELETE',
                url: path+'?object_type=profile&metadata[tag]='+encodeURIComponent(tagToRemove)
            }, opts)
            .then(function(response) {
                return response.data;
            }, function(response) {
                return response.status;
            });
    };

    tag.browseTags = function(object_type, metadata_param) {
        var path = [conf.api.root, conf.api.routes.metadata, 'browse'].join('');
        return $http.post(path, {
                "object_type": object_type,
                "metadata": metadata_param,
                "limit": 100
            }, opts)
            .then(function(response) {
                return response.data;
            }, function(response) {
                return response.status;
            });
    };

    // TODO: deleteMetadata()

    return tag;

}]);