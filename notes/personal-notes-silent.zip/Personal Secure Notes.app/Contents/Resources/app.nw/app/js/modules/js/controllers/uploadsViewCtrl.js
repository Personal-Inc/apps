angular.module('p3.attachments')
.controller('uploadsViewCtrl', function($scope, AttachmentService, conf){
	$scope.fileConf = conf.files;

	$scope.fileService.getIconFromMimeType = function(mimeType, ext){
		if(typeof mimeType !== 'undefined' && typeof mimeType[ext.toLowerCase()] !== 'undefined'){
		  return mimeType[ext.toLowerCase()];
		}
		else {
		  return 'p3-gems-noimage';
		}
	};

	// set proper icons for each file fetched
	AttachmentService.fetchFiletypesSchema().success(function(filetypes){
		$scope.fileService.globalFiletypes = filetypes;
		angular.forEach($scope.item.attachments, function(attachment){
			attachment.fileIcon = $scope.fileService.getIconFromMimeType(filetypes.mimetypes[attachment['mime-type']], attachment['name'].split('.').pop());
		});
	});

	$scope.cancelUpload = function(attachment){
		attachment.remove();
	};

	$scope.retryUpload = function(attachment){
		attachment.upload();
	};

	$scope.deleteFile = function(attachment){
		attachment.deleting = true;
		AttachmentService.deleteAttachment(attachment.id)
		.success(function(){
			$scope.item.attachments.splice($scope.item.attachments.indexOf(attachment), 1);
			$scope.fileService.status.storage.used_space -= attachment.size;
			// calculateFreePercentage();
		});
	};

	$scope.initiateFileDelete = function(attachment){
		$scope.closeInitiatedFileDeletes();
		attachment.swipedLeft = true;
	};

	  // clear all currently initated deletes, if any
	$scope.closeInitiatedFileDeletes = function(){
		angular.forEach($scope.item.attachments, function(attachment){
			if(attachment.swipedLeft) attachment.swipedLeft = false;
		});
	};

	  // convert size to human readable format
	$scope.calculateSize = function(bytes){
		if(bytes < 1024) return bytes + ' B';
		var units = ['kB','MB','GB','TB','PB','EB','ZB','YB'];
		var u = -1;
		do{
		  bytes /= 1024;
		  ++u;
		}while(bytes >= 1024);
		return bytes.toFixed(1)+' '+units[u];
	};
});