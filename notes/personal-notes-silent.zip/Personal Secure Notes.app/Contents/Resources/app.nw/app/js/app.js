var App = angular.module('app', @@appModules);
App.name = "@@appName";
App.id = "@@appId";
App.constant('config', @@settings);
App.config(
  [
      '$httpProvider',
      function($httpProvider) {
        $httpProvider.defaults.headers.common['Authorization'] = 'Cookie';
      }
  ]
);
