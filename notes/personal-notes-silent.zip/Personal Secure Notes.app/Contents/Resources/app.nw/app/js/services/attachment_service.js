/*global _: true, angular: true */
// Service for managing File Service...
// File Upload/Attach is implemented in the actual controller (by setting up uploader to post files to /file?gem_id=<owner_id>#<profile_template_id>#<gem_id>)
// Recommended File Uploader is https://github.com/nervgh/angular-file-upload
angular.module('p3.gems')
.service('AttachmentService',
  [
    '$http',
    '$q',
    'conf',
    '$log',
    '$timeout',
    function($http, $q, conf, $log, $timeout) {
      'use strict';

      var attachment = {};

      attachment.getStatus = function(){
        var path = [conf.files.root, conf.files.routes.fileservice, conf.files.routes.status].join('');
        return $http({
          url: path,
          method: 'GET',
          cache: true
        });
      };

      attachment.checkFileQueue = function(fileID){
        var def = $q.defer();
        var path = [conf.files.root, conf.files.routes.fileCheck, fileID].join('');

        var checkIt = function checkIt(fileID, def){
          $http({
            url: path,
            method: 'GET'
          })
          .success(function(status){
            if(status.status){
              def.resolve(status);
            }
            else {
              $timeout(function(){
                checkIt(fileID, def);
              }, 1000);
            }
          })
          .error(function(){
            def.reject();
          });
        }(fileID, def);

        return def.promise;
      };

      attachment.fetchFiletypesSchema = function(){
        var path = [conf.static.root, conf.static.routes.filetypes].join('');
        return $http({
          url: path,
          method: 'GET',
          cache: true
        });
      };

      attachment.deleteAttachment = function(fileID){
        var path = [conf.files.root, conf.files.routes.file+'/', fileID].join('');
        return $http({
          url: path,
          method: 'DELETE'
        });
      };

      return attachment;
    }
  ]
);